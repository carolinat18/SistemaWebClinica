<!DOCTYPE html>
<html >
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
              <link rel="stylesheet" type="text/css" href="../dist/css/dt/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../dist/css/dt/DT_bootstrap.css">
        <link rel="stylesheet" type="text/css" href="../css/style.css">
        <link rel="stylesheet" type="text/css" href="../css/demo.css">
        <script type="text/javascript" charset="utf-8" language="javascript" src="../dist/js/dt/jquery.js"></script>
        <script type="text/javascript" charset="utf-8" language="javascript" src="../dist/js/dt/jquery.dataTables.js"></script>
        <script type="text/javascript" charset="utf-8" language="javascript" src="../dist/js/dt/DT_bootstrap.js"></script>
        <script src="../dist/js/bootstrap.min.js"></script>
        <script src="../dist/js/bootbox.js"></script>	 
       <script type="text/javascript">
            function elimina(id_historia) {
                $.ajax({
                    type: "POST",
                    url: "../controllers/eHistoria_clinica.php",
                    data: "id_historia=" + id_historia,
                    success: function(html) {
                        if (html === '1') {
                            bootbox.alert("Fue eliminado correctamente", function() {
                                document.location = "iHistoria_clinica.php";
                            });
                        }
                        else {
                            bootbox.alert("No fue eliminado, verifique", function() {
                            });
                        }
                    },
                    beforeSend: function() {
                        $("#add_err").html("Loading...")
                    }
                });
            }

            function edit(id_historia, id_paciente,fecha, medicos, especialidades,tratamientos) {
                document.getElementById("id_historia").value = id_historia;
                document.getElementById("id_paciente").value = id_paciente;
                document.getElementById("fecha").value = fecha;
                document.getElementById("medicos").value = medicos;
                document.getElementById("especialidades").value = especialidades;
                document.getElementById("tratamientos").value = tratamientos;
            }

            $(document).ready(function() {

                $("#ingresar").click(function() {
                    id_historia = $("#id_historia").val();
                    id_paciente = $("#id_paciente").val();
                    fecha = $("#fecha").val();
                    medicos = $("#medicos").val();
                    especialidades = $("#especialidades").val();
                    tratamientos = $("#tratamientos").val();
                    $.ajax({
                        type: "POST",
                        url: "../controllers/iHistoria_clinica.php",
                        data: "id_historia=" + id_historia + "&id_paciente=" + id_paciente+ "&fecha=" + fecha+ "&medicos=" + medicos+ "&especialidades=" + especialidades+ "&tratamientos=" + tratamientos,
                        success: function(html) {
                            if (html == '1') {
                                bootbox.alert("Fue registrado correctamente", function() {
                                    document.location = "iHistoria_clinica.php";
                                });
                            }
                            else {
                                if (html == '2') {
                                    bootbox.alert("El registro fue modificado con éxito", function() {
                                        document.location = "iHistoria_clinica.php";
                                    });
                                }
                                else {
                                    if (html == '-1') {
                                        bootbox.alert("No fue procesado, verifique", function() {
                                        });
                                    }
                                    else {
                                        bootbox.alert("No fue registrado, verifique", function() {
                                        });
                                    }
                                }
                            }
                        },
                        beforeSend: function() {
                            $("#add_err").html("Loading...");
                        }
                    });
                    return false;
                });
            });
        </script>
   </head>
   <body>
                      <form class="form-horizontal" role="form">
                    <h3>Historias Clínicas</h3>
                    <div class="form-group">
                        <label for="id_historia" class="col-sm-2 control-label">Id Historia</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="id_historia" placeholder="Id de historia clínica" required />
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="id_paciente" class="col-sm-2 control-label">Id Paciente</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="id_paciente" placeholder="Id paciente" required />
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="fecha" class="col-sm-2 control-label">Fecha</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="fecha" placeholder="Fecha" required />
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="medicos" class="col-sm-2 control-label">Médicos</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="medicos" placeholder="Médicos" required />
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="especialidades" class="col-sm-2 control-label">Especialidades</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="especialidades" placeholder="Especialidades" required />
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="tratamientos" class="col-sm-2 control-label">Tratamientos</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="tratamientos" placeholder="Tratamientos" required />
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button id="ingresar" type="submit" class="btn">Guardar</button>
                            <a href="../PDF/ReporteHistoria_clinica_pdf.php" > <div class="btn">Generar informe en PDF</div></a>
                        </div>
                    </div>
                </form>
                <?php
                ini_set('display_errors', 'on');
                include_once("../modelo/class.historia_clinica.php");
                $obj = new historia_clinica();
                $obj->getTabla();
                ?>
        
               </body>
</html>
