<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <link href="../icono.ico" type="image/x-icon" rel="shortcut icon" />
        <title>Paciente</title>

        <link rel="stylesheet" type="text/css" href="../dist/css/dt/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../dist/css/dt/DT_bootstrap.css">
        <link rel="stylesheet" type="text/css" href="../dist/css/../css/../../css/style.css">
        <link rel="stylesheet" type="text/css" href="../css/demo.css">
        <script type="text/javascript" charset="utf-8" language="javascript" src="../dist/js/dt/jquery.js"></script>
        <script type="text/javascript" charset="utf-8" language="javascript" src="../dist/js/dt/jquery.dataTables.js"></script>
        <script type="text/javascript" charset="utf-8" language="javascript" src="../dist/js/dt/DT_bootstrap.js"></script>
        <script src="../dist/js/bootstrap.min.js"></script>
        <script src="../dist/js/bootbox.js"></script>	 

        <script type="text/javascript">
            function elimina(id_paciente) {
                $.ajax({
                    type: "POST",
                    url: "../controllers/ePaciente.php",
                    data: "id_paciente=" + id_paciente,
                    success: function (html) {
                        if (html === '1') {
                            bootbox.alert("Fue eliminado correctamente", function () {
                                document.location = "iPaciente.php";
                            });
                        } else {
                            bootbox.alert("No fue eliminado, verifique", function () {
                            });
                        }
                    },
                    beforeSend: function () {
                        $("#add_err").html("Loading...")
                    }
                });
            }

            function edit(id_paciente, nombre, apellido, fecha_nacimiento, direccion, telefono_contacto, correo_electronico) {
                document.getElementById("id_paciente").value = id_paciente;
                document.getElementById("nombre").value = nombre;
                document.getElementById("apellido").value = apellido;
                document.getElementById("fecha_nacimiento").value = fecha_nacimiento;
                document.getElementById("direccion").value = direccion;
                document.getElementById("telefono_contacto").value = telefono_contacto;
                document.getElementById("correo_electronico").value = correo_electronico;

            }

            $(document).ready(function () {

                $("#boton").click(function () {
                    id_paciente = $("#id_paciente").val();
                    nombre = $("#nombre").val();
                    apellido = $("#apellido").val();
                    fecha_nacimiento = $("#fecha_nacimiento").val();
                    direccion = $("#direccion").val();
                    telefono_contacto = $("#telefono_contacto").val();
                    correo_electronico = $("#correo_electronico").val();

                    $.ajax({
                        type: "POST",
                        url: "../controllers/iPaciente.php",
                        data: "id_paciente=" + id_paciente + "&nombre=" + nombre + "&apellido=" + apellido + "&fecha_nacimiento=" + fecha_nacimiento + "&direccion=" + direccion + "&telefono_contacto=" + telefono_contacto+ "&correo_electronico=" + correo_electronico,
                        success: function (html) {
                            alert(html);
                            if (html === '1') {
                                bootbox.alert("Fue registrado correctamente", function () {
                                    document.location = "iPaciente.php";
                                });
                            } else {
                                if (html === '2') {
                                    bootbox.alert("El registro fue modificado con éxito", function () {
                                        document.location = "iPaciente.php";
                                    });
                                } else {
                                    if (html === '-1') {
                                        bootbox.alert("No fue procesado, verifique", function () {
                                        });
                                    } else {
                                        bootbox.alert("No fue registrado, verifique", function () {
                                        });
                                    }
                                }
                            }
                        },
                        beforeSend: function () {
                            $("#add_err").html("Loading...");
                        }
                    });
                    return false;
                });

                $("#listar").click(function () {
                    location.href = "ReportePacientes.php";
                });
            });
        </script>

    </head>

    <body>
        <form class="form-horizontal" role="form">
            <h3>Pacientes</h3>
            <div class="form-group">
                <label for="id_paciente" class="col-sm-2 control-label">Id</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="id_paciente" placeholder="Id" required />
                </div>
                <label for="nombre" class="col-sm-2 control-label">Nombre</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="nombre" placeholder="Nombre" required />
                </div>
                <label for="apellido" class="col-sm-2 control-label">Apellido</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="apellido" placeholder="Apellido" required />
                </div>
                <label for="fecha_nacimiento" class="col-sm-2 control-label">Fecha de Nacimiento</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="fecha_nacimiento" placeholder="Fecha de Nacimiento" required />
                </div>
                <label for="direccion" class="col-sm-2 control-label">Dirección</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="direccion" placeholder="Dirección" required />
                </div>
                <label for="telefono_contacto" class="col-sm-2 control-label">Teléfono</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="telefono_contacto" placeholder="Teléfono" required />
                </div>
                <label for="correo_electronico" class="col-sm-2 control-label">Correo electrónico</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="correo_electronico" placeholder="Correo electrónico" required />
                </div>
            </div>
                   
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button id="boton" type="submit" class="btn">Guardar</button><br>
                    <a href="../PDF/ReportePacientes_pdf.php" > <div class="btn">Generar informe en PDF</div></a>
                </div>
            </div>
        </form>
        <?php
        ini_set('display_errors', 'on');
        include_once("../modelo/class.paciente.php");
        $obj = new paciente();
        $obj->getTabla();
        ?>
    </body>
</html>

