<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <link href="icono.ico" type="image/x-icon" rel="shortcut icon" />

        <title>Citas</title>

        <link rel="stylesheet" type="text/css" href="../dist/css/dt/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../dist/css/dt/DT_bootstrap.css">
        <link rel="stylesheet" type="text/css" href="../css/demo.css">
        <link rel="stylesheet" type="text/css" href="../dist/css/../css/../../css/style.css">
        <script type="text/javascript" charset="utf-8" language="javascript" src="../dist/js/dt/jquery.js"></script>
        <script type="text/javascript" charset="utf-8" language="javascript" src="../dist/js/dt/jquery.dataTables.js"></script>
        <script type="text/javascript" charset="utf-8" language="javascript" src="../dist/js/dt/DT_bootstrap.js"></script>
        <script src="../dist/js/bootstrap.min.js"></script>
        <script src="../dist/js/bootbox.js"></script>	 

        <script type="text/javascript">
            function elimina(id_cita) {
                $.ajax({
                    type: "POST",
                    url: "../controllers/eCitas.php",
                    data: "id_cita=" + id_cita,
                    success: function (html) {
                        alert(html);
                        if (html === '1') {
                            bootbox.alert("Fue eliminado correctamente", function () {
                                document.location = "iCitas.php";
                            });
                        } else {
                            bootbox.alert("No fue eliminado, verifique", function () {
                            });
                        }
                    },
                    beforeSend: function () {
                        $("#add_err").html("Loading...")
                    }
                });
            }

            function edit(id_cita,id_paciente, medico, especialidad, fecha_hora, direccion_cita) {
                document.getElementById("id_cita").value = id_cita;
                document.getElementById("id_paciente").value = id_paciente;
                document.getElementById("medico").value = medico;
                document.getElementById("especialidad").value = especialidad;
                document.getElementById("fecha_hora").value = fecha_hora;
                document.getElementById("direccion_cita").value = direccion_cita;

            }

            $(document).ready(function () {

                $("#ingresar").click(function () {
                    id_cita = $("#id_cita").val();
                    id_paciente = $("#id_paciente").val();
                    medico = $("#medico").val();
                    especialidad = $("#especialidad").val();
                    fecha_hora = $("#fecha_hora").val();
                    direccion_cita = $("#direccion_cita").val();

                    $.ajax({
                        type: "POST",
                        url: "../controllers/iCitas.php",
                        data: "id_cita=" + id_cita + "&id_paciente=" + id_paciente + "&medico=" + medico + "&especialidad=" + especialidad + "&fecha_hora=" + fecha_hora + "&direccion_cita=" + direccion_cita,
                        success: function (html) {
                            alert(html);
                            if (html == '1') {
                                bootbox.alert("Fue registrado correctamente", function () {
                                    document.location = "iCitas.php";
                                });
                            } else {
                                if (html == '2') {
                                    bootbox.alert("El registro fue modificado con éxito", function () {
                                        document.location = "iCitas.php";
                                    });
                                } else {
                                    if (html == '-1') {
                                        bootbox.alert("No fue procesado, verifique", function () {
                                        });
                                    } else {
                                        bootbox.alert("No fue registrado, verifique", function () {
                                        });
                                    }
                                }
                            }
                        },
                        beforeSend: function () {
                            $("#add_err").html("Loading...");
                        }
                    });
                    return false;
                });
            });
        </script>
    <div class="gradeA odd"></div>
</head>

<body>
    <form class="form-horizontal" role="form">
        <h3>Citas</h3>
        <div class="form-group">
            <label for="id_cita" class="col-sm-2 control-label">Id Cita</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="id_cita" placeholder="Id de la cita" required />
            </div>
        </div>
        <div class="form-group">
            <label for="id_paciente" class="col-sm-2 control-label">Id Paciente</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="id_paciente" placeholder="" required autofocus="" />
            </div>
        </div>
        <div class="form-group">
            <label for="medico" class="col-sm-2 control-label">Médico</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="medico" placeholder="Medico" required />
            </div>
        </div>
                <div class="form-group">
            <label for="especialidad" class="col-sm-2 control-label">Especialidad</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="especialidad" placeholder="Especialidad" required />
            </div>
        </div>
        <div class="form-group">
            <label for="fecha_hora" class="col-sm-2 control-label">Fecha y hora</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="fecha_hora" placeholder="Fecha y hora" required />
            </div>
        </div>
        <div class="form-group">
            <label for="direccion_cita" class="col-sm-2 control-label">Dirección cita</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="direccion_cita" placeholder="Dirección cita" required />
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <button id="ingresar" type="submit" class="btn">Guardar</button>
                <a href="../PDF/ReporteCitas_pdf.php" > <div class="btn">Generar informe en PDF</div></a>
            </div>
        </div>
    </form>
    <?php
    ini_set('display_errors', 'on');
    include_once("../modelo/class.citas.php");
    $obj = new citas();
    $obj->getTabla();
    ?>

</body>
</html>
