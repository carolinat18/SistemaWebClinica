<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <link href="icono.ico" type="image/x-icon" rel="shortcut icon" />

        <title>Registro de gastos</title>

        <link rel="stylesheet" type="text/css" href="../dist/css/dt/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../dist/css/dt/DT_bootstrap.css">
        <link rel="stylesheet" type="text/css" href="../dist/css/../css/../../css/style.css">
        <link rel="stylesheet" type="text/css" href="../css/demo.css">
        <script type="text/javascript" charset="utf-8" language="javascript" src="../dist/js/dt/jquery.js"></script>
        <script type="text/javascript" charset="utf-8" language="javascript" src="../dist/js/dt/jquery.dataTables.js"></script>
        <script type="text/javascript" charset="utf-8" language="javascript" src="../dist/js/dt/DT_bootstrap.js"></script>
        <script src="../dist/js/bootstrap.min.js"></script>
        <script src="../dist/js/bootbox.js"></script>	 

        <script type="text/javascript">
            function elimina(concepto, cierre) {
                $.ajax({
                    type: "POST",
                    url: "../controllers/eGasto.php",
                    data: "concepto=" + concepto + "&cierre=" + cierre,
                    success: function(html) {
                        alert(html);
                        if (html === '1') {
                            bootbox.alert("Fue eliminado correctamente", function() {
                                document.location = "iGasto.php";
                            });
                        }
                        else {
                            bootbox.alert("No fue eliminado, verifique", function() {
                            });
                        }
                    },
                    beforeSend: function() {
                        $("#add_err").html("Loading...")
                    }
                });
            }

            function edit(valor, pagado_a, concepto, cierre) {
                document.getElementById("valor").value = valor;
                document.getElementById("pagado_a").value = pagado_a;
                document.getElementById("concepto").value = concepto;
                document.getElementById("cierre").value = cierre;
            }

            $(document).ready(function() {

                $("#ingresar").click(function() {
                    valor = $("#valor").val();
                    pagado_a = $("#pagado_a").val();
                    concepto = $("#concepto").val();
                    cierre = $("#cierre").val();
                    $.ajax({
                        type: "POST",
                        url: "../controllers/iGasto.php",
                        data: "valor=" + valor + "&pagado_a=" + pagado_a + "&concepto=" + concepto + "&cierre=" + cierre,
                        success: function(html) {
                            alert(html);
                            if (html == '1') {
                                bootbox.alert("Fue registrado correctamente", function() {
                                    document.location = "iGasto.php";
                                });
                            }
                            else {
                                if (html == '2') {
                                    bootbox.alert("El registro fue modificado con éxito", function() {
                                        document.location = "iGasto.php";
                                    });
                                }
                                else {
                                    if (html == '-1') {
                                        bootbox.alert("No fue procesado, verifique", function() {
                                        });
                                    }
                                    else {
                                        bootbox.alert("No fue registrado, verifique", function() {
                                        });
                                    }
                                }
                            }
                        },
                        beforeSend: function() {
                            $("#add_err").html("Loading...");
                        }
                    });
                    return false;
                });
            });
        </script>

    </head>

    <body>
        <form class="form-horizontal" role="form">
            <h3>Gastos</h3>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Valor</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="valor" placeholder="Valor del gasto" required />
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Pagado a</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="pagado_a" placeholder="Empresa o persona" required />
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Por concepto de</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="concepto" placeholder="Motivo del gasto" required />
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Fecha del cierre</label>
                <?php
                ini_set('display_errors', 'on');
                include_once("../modelo/class.gasto.php");
                $obj = new gasto();
                $obj->getComboBox();
                ?>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button id="ingresar" type="submit" class="btn">Guardar</button>
                    <a href="../PDF/ReporteGastos_pdf.php" > <div class="btn">Generar informe en PDF</div></a>
                </div>
            </div>
        </form>
        <?php
        ini_set('display_errors', 'on');
        include_once("../modelo/class.gasto.php");
        $obj = new gasto();
        $obj->getTabla();
        ?>
    </body>
</html>
