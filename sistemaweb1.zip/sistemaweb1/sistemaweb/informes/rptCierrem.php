<html>
    <head>
        <meta http-equiv="content-type" content="text/html;charset=utf-8" />
        <link rel="stylesheet" type="text/css" href="../dist/css/dt/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../dist/css/dt/DT_bootstrap.css">
        <link rel="stylesheet" type="text/css" href="../dist/css/../css/../../css/style.css">
        <link rel="stylesheet" type="text/css" href="../css/demo.css">
        <script type="text/javascript" charset="utf-8" language="javascript" src="../dist/js/dt/jquery.js"></script>
        <script type="text/javascript" charset="utf-8" language="javascript" src="../dist/js/dt/jquery.dataTables.js"></script>
        <script type="text/javascript" charset="utf-8" language="javascript" src="../dist/js/dt/DT_bootstrap.js"></script>
        <script src="../dist/js/bootstrap.min.js"></script>
        <script src="../dist/js/bootbox.js"></script>
        <link href="icono.ico" type="image/x-icon" rel="shortcut icon" />
        <title>Reporte-Cierre</title>
    </head>
    <body>
        <h3>Día en el que se han obtenido menores ingresos </h3>  
       <?php
        ini_set('display_errors', 'on');
        include_once("../modelo/class.cierre.php");
        $obj = new cierre();
        $obj->getTablaValorMenor();
        ?>
        <a href="../PDF/rptCierreM_pdf.php" > <div class="btn">Generar informe en PDF</div></a>
    </body>
</html>

