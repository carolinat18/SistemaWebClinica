<?php

ini_set('display_errors', 'on');
session_start();
include_once("../modelo/class.resultados_examenes.php");
$obj = new resultados_examenes();
if (isset($_POST['id_resultado']) && isset($_POST['id_paciente']) && isset($_POST['fecha']) && isset($_POST['medico']) && isset($_POST['especialidad']) && isset($_POST['fecha_resultado'])) {
    $obj->id_resultado = $_POST['id_resultado'];
    $obj->id_paciente = $_POST['id_paciente'];
    $obj->fecha = $_POST['fecha'];
    $obj->medico = $_POST['medico'];
    $obj->especialidad = $_POST['especialidad'];
    $obj->fecha_resultado = $_POST['fecha_resultado'];
    echo $obj->insert();
} else {
    echo "-1";
}

