<?php

ini_set('display_errors', 'on');
session_start();
include_once("../modelo/class.solicitudes_autorizaciones.php");
$obj = new solicitudes_autorizaciones();
if (isset($_POST['id_solicitud']) && isset($_POST['id_paciente']) && isset($_POST['medico']) && isset($_POST['especialidad']) && isset($_POST['fecha_hora']) && isset($_POST['tipo_tratamiento'])) {
    $obj->id_solicitud = $_POST['id_solicitud'];
    $obj->id_paciente = $_POST['id_paciente'];
    $obj->medico = $_POST['medico'];
    $obj->especialidad = $_POST['especialidad'];
    $obj->fecha_hora = $_POST['fecha_hora'];
    $obj->tipo_tratamiento = $_POST['tipo_tratamiento'];
    echo $obj->insert();
} else {
    echo "-1";
}

