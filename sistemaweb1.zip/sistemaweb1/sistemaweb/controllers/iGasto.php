<?php

ini_set('display_errors', 'on');
session_start();
include_once("../modelo/class.gasto.php");
$obj = new gasto();
if (isset($_POST['valor']) && isset($_POST['pagado_a']) && isset($_POST['concepto']) && isset($_POST['cierre'])) {
    $obj->valor = $_POST['valor'];
    $obj->pagado_a = $_POST['pagado_a'];
    $obj->concepto = $_POST['concepto'];
    $obj->cierre = $_POST['cierre'];
    echo $obj->insert();
} else {
    echo "-1";
}
