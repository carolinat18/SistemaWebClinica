<?php ini_set('display_errors', 'on');
 session_start();// Mostrar errores y advertencias
	include_once("../modelo/class.usuario.php"); // Incluir la clase (código fuente)
	$obj = new usuario(); // Instancia la clase (crea el objeto)
	$res="";
	if (isset($_POST['usuario'])){ // Valida que si esté parámetro
		$res=$obj->valide($_POST['usuario'], $_POST['password']);
	}  else {
            session_destroy();
}
	echo $res;
        header("Location:../index.php");
    ?>
