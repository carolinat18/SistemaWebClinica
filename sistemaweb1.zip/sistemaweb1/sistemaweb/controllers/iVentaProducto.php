<?php

ini_set('display_errors', 'on');
session_start();
include_once("../modelo/class.ventaproducto.php");
$obj = new ventaproducto();
if (isset($_POST['idventa']) && isset($_POST['idproducto']) && isset($_POST['cantidad']) && isset($_POST['fecha'])) {
    $obj->idproducto = $_POST['idproducto'];
    $obj->idventa = $_POST['idventa'];
    $obj->cantidad = $_POST['cantidad'];
    $obj->fecha = $_POST['fecha'];
    echo $obj->insert();
} else {
    echo "-1";
}
?>
