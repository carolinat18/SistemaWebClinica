<?php
	ini_set('display_errors', 'on');
	session_start();
	include_once("../modelo/class.venta.php");
	$obj = new venta();
	if (isset($_POST['id'])){
		echo $obj->delete($_POST['id']);
	}
	else{
		echo "-2";
	}
?>
