<?php

ini_set('display_errors', 'on');
session_start();
include_once("../modelo/class.cliente.php");
$obj = new cliente();
if (isset($_POST['id']) && isset($_POST['cedula']) && isset($_POST['nombre']) && isset($_POST['telefono'])) {
    $obj->id = $_POST['id'];
    $obj->cedula = $_POST['cedula'];
    $obj->nombre = $_POST['nombre'];
    $obj->telefono = $_POST['telefono'];

    echo $obj->insert();
} else {
    echo "-1";
}
?>
