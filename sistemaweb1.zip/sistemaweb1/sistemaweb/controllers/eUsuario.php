<?php
	ini_set('display_errors', 'on');
	session_start();
	include_once("../modelo/class.usuario.php");
	$obj = new usuario();
	if (isset($_POST['id'])){
		echo $obj->delete($_POST['id']);
	}
	else{
		echo "-2";
	}
