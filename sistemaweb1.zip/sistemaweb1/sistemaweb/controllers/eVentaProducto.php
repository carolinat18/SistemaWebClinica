<?php
	ini_set('display_errors', 'on');
	session_start();
	include_once("../modelo/class.ventaproducto.php");
	$obj = new ventaproducto();
	if (isset($_POST['idventa'])){
		echo $obj->delete($_POST['idventa']);
	}
	else{
		echo "-2";
	}
?>
