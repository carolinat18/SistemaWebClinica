<?php

ini_set('display_errors', 'on');
session_start();
include_once("../modelo/class.historia_clinica.php");
$obj = new historia_clinica();
if (isset($_POST['id_historia']) && isset($_POST['id_paciente']) && isset($_POST['fecha']) && isset($_POST['medicos']) && isset($_POST['especialidades']) && isset($_POST['tratamientos'])) {
    $obj->id_historia = $_POST['id_historia'];
    $obj->id_paciente = $_POST['id_paciente'];
    $obj->fecha = $_POST['fecha'];
    $obj->medicos = $_POST['medicos'];
    $obj->especialidades = $_POST['especialidades'];
    $obj->tratamientos = $_POST['tratamientos'];

    echo $obj->insert();
} else {
    echo "-1";
}
?>
