<?php

ini_set('display_errors', 'on');
session_start();
include_once("../modelo/class.citas.php");
$obj = new citas();
if (isset($_POST['id_cita']) && isset($_POST['id_paciente']) && isset($_POST['medico']) && isset($_POST['especialidad'])&& isset($_POST['fecha_hora']) && isset($_POST['direccion_cita'])) {
    $obj->id_cita = $_POST['id_cita'];
    $obj->id_paciente = $_POST['id_paciente'];
    $obj->medico = $_POST['medico'];
    $obj->especialidad = $_POST['especialidad'];
    $obj->fecha_hora = $_POST['fecha_hora'];
    $obj->direccion_cita = $_POST['direccion_cita'];
    echo $obj->insert();
} else {
    echo "-1";
}
?>
