<?php
	ini_set('display_errors', 'on');
	session_start();
	include_once("../modelo/class.historia_clinica.php");
	$obj = new historia_clinica();
	if (isset($_POST['id_historia_clinica'])){
		echo $obj->delete($_POST['id_historia_clinica']);
	}
	else{
		echo "-2";
	}
        
