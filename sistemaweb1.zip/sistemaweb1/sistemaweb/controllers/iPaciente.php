<?php

ini_set('display_errors', 'on');
session_start();
include_once("../modelo/class.paciente.php");
$obj = new paciente();



if (isset($_POST['id_paciente']) && isset($_POST['nombre']) && isset($_POST['apellido']) && isset($_POST['fecha_nacimiento']) && isset($_POST['direccion']) && isset($_POST['telefono_contacto'])&& isset($_POST['correo_electronico'])) {
    $obj->id_paciente = $_POST['id_paciente'];
    $obj->nombre = $_POST['nombre'];
    $obj->apellido = $_POST['apellido'];
    $obj->fecha_nacimiento = $_POST['fecha_nacimiento'];
    $obj->direccion = $_POST['direccion'];
    $obj->telefono_contacto = $_POST['telefono_contacto'];
    $obj->correo_electronico = $_POST['correo_electronico'];
    echo $obj->insert();
} else {
    echo "-1";
}

 function listarInformacion(){
     echo 'Desde el controlador';
     require ("../modelo/class.paciente.php");
     $objModelo= new paciente();
     $res=$objModelo->getLista();
     return $res;
    }
    
    function  prueba(){
        echo 'Desde el controlador';
    }