<?php
ini_set('display_errors', 'on'); // Mostrar errores y advertencias
include_once("../modelo/class.usuario.php"); // Incluir la clase (código fuente)
$obj = new usuario(); // Instancia la clase (crea el objeto)
$res = "";
if (isset($_POST['nombre']) && isset($_POST['password'])) { // Valida que si esté parámetro
    $res = $obj->validaLogin($_POST['nombre'], $_POST['password']);
}
if ($res == false) {
    echo "2";
} else {
    echo "1";
    }
?>
