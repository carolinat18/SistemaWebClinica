<?php
	ini_set('display_errors', 'on');
	session_start();
	include_once("../modelo/class.cliente.php");
	$obj = new cliente();
	if (isset($_POST['id'])){
		echo $obj->delete($_POST['id']);
	}
	else{
		echo "-2";
	}
?>
