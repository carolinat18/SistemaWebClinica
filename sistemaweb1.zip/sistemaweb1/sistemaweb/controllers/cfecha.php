<?php

ini_set('display_errors', 'of');
include_once("../modelo/class.cierre.php");
$obj = new cierre();
$res = "";
if (isset($_POST['fechai'])&& isset($_POST['fechaf'])) {
    $res = $obj->consultafecha($_POST['fechai'])&&($_POST['fechaf']);
}
if ($res == "-1") {
    echo "El registro no se encuentra en la base de datos";
} else {
    echo "La descripción es: " . $res;
}
?>
