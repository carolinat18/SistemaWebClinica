<?php
	ini_set('display_errors', 'on');
	session_start();
	include_once("../modelo/class.producto.php");
	$obj = new producto();
	if (isset($_POST['id'])){
		echo $obj->delete($_POST['id']);
	}
	else{
		echo "-2";
	}
?>
