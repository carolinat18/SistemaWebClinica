<?php

ini_set('display_errors', 'on');
session_start();
include_once("../modelo/class.usuario.php");
$obj = new usuario();
if ( isset($_POST['usuario']) && isset($_POST['password'])) {
 
    $obj->usuario = $_POST['usuario'];
    $obj->password = $_POST['password'];
   
    echo $obj->insert();
} else {
    echo "-1";
}
?>
