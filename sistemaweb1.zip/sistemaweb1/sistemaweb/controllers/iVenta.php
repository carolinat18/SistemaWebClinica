<?php
	ini_set('display_errors', 'on');
	session_start();
	include_once("../modelo/class.venta.php");
	$obj = new venta();
	if (isset($_POST['id']) && isset($_POST['cliente'])){
		$obj->id=$_POST['id'];
		$obj->cliente=$_POST['cliente'];
		echo $obj->insert();
	}
	else{
		echo "-1";
	}
?>
