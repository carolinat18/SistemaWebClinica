<!DOCTYPE html>
<?php
session_start();
?>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <link href="../icono.ico" type="image/x-icon" rel="shortcut icon" />
        <title>Inicio</title>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />

        <link rel="stylesheet" href="../css/stylemenu.css" type="text/css" /><style type="text/css">._css3m{
                display:none
            }</style>
        <link rel="stylesheet" type="text/css" href="../dist/css/dt/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../dist/css/dt/DT_bootstrap.css"> 
        <link rel="stylesheet" type="text/css" href="../css/style.css">
        <script type="text/javascript" charset="utf-8" language="javascript" src="../dist/js/dt/jquery.js"></script>
        <script type="text/javascript" charset="utf-8" language="javascript" src="../dist/js/dt/jquery.dataTables.js"></script>
        <script type="text/javascript" charset="utf-8" language="javascript" src="../dist/js/dt/DT_bootstrap.js"></script>
        <script src="../dist/js/bootstrap.min.js"></script>
        <script src="../dist/js/bootbox.js"></script>	 
    </head>
    <body>

        <div id="contenedor">
            <header>  </header>
            <?php
            if (count($_SESSION) > 0) {
                ?>
                <div id="sesion"><form class="formsession" action="../controllers/validar.php"method="post">
                        <input type="submit" class="botonsesion"value=" Cerrar Sesión"/>
                    </form>Usuario: <?php echo $_SESSION['usuario']; ?></div>
                <div id="menu">
                    <ul id="css3menu1" class="topmenu">
                        <input type="checkbox" id="css3menu-switcher" class="switchbox"><label onclick="" class="switch" for="css3menu-switcher"></label>	<li class="topfirst"><a class="pressed" href="inicio.php?view=inicio" style="width:151px;"><img src="../images/256base-home-over.png" alt=""/>Inicio</a></li>
                        <li class="topmenu"><a href="#" style="width:151px;"><span><img src="../images/btour1.jpg" alt=""/>Gestión de citas</span></a>
                            <ul>
                                <li class="subfirst"><a href="inicio.php?view=historia_clinica">Historias clínicas</a></li>
                                <li><a href="inicio.php?view=citas">Citas</a></li>
                                <li><a href="inicio.php?view=paciente">Pacientes</a></li>
                                <li><a href="inicio.php?view=resultados_examenes">Resultados de examenes</a></li>
                                <li><a href="inicio.php?view=solicitudes_autorizaciones">Solicitudes Autorizaciones</a></li>
                                <li><a href="inicio.php?view=usuario">Usuarios</a></li>
                            </ul></li>
                        <li class="topmenu"><a href="inicio.php?view=paciente" style="width:151px;"><img src="../images/bbuy1.png" alt=""/>Pacientes</a></li>
                        <li class="topmenu"><a href="#" style="width:151px;"><span><img src="../images/256base-save-over1.png" alt=""/>Informes</span></a>
                            <ul>
                                <li><a href="inicio.php?view=resultados_examenes"><img src="../images/coin2.png" alt=""/>Resultados de examenes</a></li>
                            </ul></li>
                        <li class="topmenu"><a href="inicio.php?view=servicios" style="width:151px;"><img src="../images/bnews.png" alt=""/>Servicios</a></li>
                    </ul><p class="_css3m"><a href="http://css3menu.com/">menu html5</a> by Css3Menu.com</p>

                </div>



                <div id="contenedorformulario"  >
                    <?php
                    if (isset($_GET["view"])) {
                        $menu = $_GET["view"];
                        switch ($menu) {
                            case "inicio":
                                echo '<iframe src="../images/bienvenido.jpg" ></iframe>';
                                break;

                            case "historia_clinica":
                                echo '<iframe src="../CRUDs/iHistoria_clinica.php" ></iframe>';
                                break;

                            case "paciente":
                                echo '<iframe src="../CRUDs/iPaciente.php" ></iframe>';
                                break;

                            case "resultados_examenes":
                                echo '<iframe src="../CRUDs/iResultados_examenes.php" ></iframe>';
                                break;

                            case "solicitudes_autorizaciones":
                                echo '<iframe src="../CRUDs/iSolicitudes_autorizaciones.php" ></iframe>';
                                break;

                            case "citas":
                                echo '<iframe src="../CRUDs/iCitas.php" ></iframe>';
                                break;

                            case "usuario":
                                echo '<iframe src="../CRUDs/registrarusuario.php" ></iframe>';
                                break;

                            case "resultados_examenes":
                                echo '<iframe src="../informes/rptResultados_exameness.php" ></iframe>';
                                break;

                            case "paciente":
                                echo '<iframe src="../images/pacientes.jpg" ></iframe>';
                                break;

                            default:
                                echo '<iframe src="../error.php" ></iframe>';
                                break;
                        }
                    }
                } else {
                    echo '<strong>Usted no se ha identificado debe <a href="../index.php">Loguearse</a></strong>"';
                }
                ?>
            </div>
            <footer> <strong>Todos los derechos reservados - Riosucio - Caldas - Colombia, <?php echo date("Y"); ?> - &copy;</strong></footer>
        </div>
    </body>
</html>