<!Doctype html>
<html>
<body>
    <h1>Bienvenido</h1>
    <style> table{border: #000055;background: #adadad;margin: auto; width: auto;}
        td{margin: 20px; border: 2px;}tr{margin:  30px; }</style>
    <table cellpadding='0' cellspacing='0' border='0' class='table table-striped table-bordered' id='example'></table>
</body>
</html>

