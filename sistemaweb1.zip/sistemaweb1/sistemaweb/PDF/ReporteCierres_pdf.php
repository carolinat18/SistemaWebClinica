<?php

	require("../dist/html2fpdf/html2pdf.class.php");
	include_once("../modelo/class.cierre.php");	

	$html2pdf = new HTML2PDF('P','Letter','es','true','UTF-8', array(10, 10, 10, 10));
	$result="<h3>Listado de Cierres (Balances Diarios)</h3>";
	
	$obj = new cierre();
	$result=$result . $obj->getTablaPDF();
	$html2pdf->writeHTML($result);
	$html2pdf->Output('res.pdf', 'I');
?>

