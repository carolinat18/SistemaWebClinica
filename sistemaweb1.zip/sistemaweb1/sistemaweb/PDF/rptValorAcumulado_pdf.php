<?php

	require("../dist/html2fpdf/html2pdf.class.php");
	include_once("../modelo/class.cierre.php");	

	$html2pdf = new HTML2PDF('P','Letter','es','true','UTF-8', array(10, 10, 10, 10));
	$result="<h3>Total de ingresos hasta la fecha</h3>";
	
	$obj = new cierre();
	$result=$result . $obj->getValorAcumuladoPDF();
	$html2pdf->writeHTML($result);
	$html2pdf->Output('res.pdf', 'I');
?>