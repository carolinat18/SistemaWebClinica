<?php

	require("../dist/html2fpdf/html2pdf.class.php");
	include_once("../modelo/class.venta.php");	

	$html2pdf = new HTML2PDF('P','Letter','es','true','UTF-8', array(10, 10, 10, 10));
	$result="<h3>Compras de Clientes</h3>";
	
	$obj = new venta();
	$result=$result . $obj->getTablaClientesPDF();
	$html2pdf->writeHTML($result);
	$html2pdf->Output('res.pdf', 'I');
?>