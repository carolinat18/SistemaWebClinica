<?php

ini_set('display_errors', 'off');
include_once("resources/class.database.php");

class gasto {

    var $valor;
    var $pagado_a;
    var $concepto;
    var $cierre;

    function gasto() {
        
    }

    function select($concepto, $cierre) {
        $sql = "SELECT * FROM admin.gasto WHERE concepto = '$concepto' and cierre=$cierre";
        try {
            $row = pg::query($sql);
            $row = pg_fetch_array($row);
            $this->valor = $row['valor'];
            $this->pagado_a = $row['pagado_a'];
            $this->concepto = $row['concepto'];
            $this->cierre = $row['cierre'];
            return true;
        } catch (DependencyException $e) {
            
        }
    }

 
    function insert() {
        
            $sql = "INSERT INTO admin.gasto(valor, pagado_a, concepto, cierre) VALUES (" . $this->valor . ", ' " . $this->pagado_a . " ', ' " . $this->concepto . " ', " . $this->cierre . ")";
            try {
                pg::query("begin");
                $row = pg::query($sql);
                pg::query("commit");
                echo "1";
            } catch (DependencyException $e) {
                echo "Error: " . $e;
                pg::query("rollback");
                echo "-1";
            }
        } 
    

    

    function getTabla() {

        $sql = "select  gasto.valor, gasto.pagado_a, gasto.concepto,cierre.fecha
from admin.gasto, admin.cierre
where admin.gasto.cierre = admin.cierre.idcierre";
        try {
            echo "<div class='container' style='margin-top: 10px'>";
            echo "<table cellpadding=auto cellspacing=auto border='0' class='table table-striped table-bordered' id='example'>";
            echo "<thead>";
            echo "<tr>";
            echo "	<th>Valor</th>";
            echo "	<th>Pagado a</th>";
            echo "	<th>Por concepto de</th>";
            echo "	<th>Fecha del Cierre</th>";
           
            echo "</tr>";
            echo "</thead>";
            echo "<tbody>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<tr class='gradeA'>";
                echo "	<th>" . $row['valor'] . "</th>";
                echo "	<th>" . $row['pagado_a'] . "</th>";
                echo "	<th>" . $row['concepto'] . "</th>";
                echo "	<th>" . $row['fecha'] . "</th>";
                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
            echo "</div>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
    }

    function getLista() {

        $sql = "SELECT * FROM administrador.tbl_actividad";
        try {
            echo "<SELECT name='id'>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<OPTION value='" . $row['id'] . "'> " . $row['descripcion'] . " </OPTION>";
            }
            echo "</SELECT>";
        } catch (DependencyException $e) {
            pg::query("rollback");
        }
    }

    function getAutocomplete() {
        $res = "";
        $sql = "SELECT * FROM administrador.tbl_actividad";
        try {
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $res .= '"' . $row['id'] . ', ' . $row['descripcion'] . '"';
                $res .= ',';
            }
            $res = substr($res, 0, -2);
            $res = substr($res, 1);
        } catch (DependencyException $e) {
            
        }
        return $res;
    }

    function getComboBox() {

        $sql = "SELECT * FROM admin.cierre";
        try {
            echo "<SELECT name='cierre' id='cierre'>";
            //pg::query("begin");
            $result = pg::query($sql);
            //pg::query("commit");
            while ($row = pg_fetch_array($result)) {
                echo "<OPTION value='" . $row['idcierre'] . "'> " . $row['fecha'] . " </OPTION>";
            }
            echo "</SELECT>";
        } catch (DependencyException $e) {
            pg::query("rollback");
        }
    }

    function getTablaPDF() {

        $sql = "select * from admin.gasto";
        $tabla = "";
        try {
            $tabla = "<table <style> table{background: #F0F0F0 !important; margin-top:40px; width: auto;}
        td{padding: 10px;}tr{padding:20px; }</style>>";
            $tabla = $tabla . "<tr>";
            $tabla = $tabla . "	<td>Valor</td>";
            $tabla = $tabla . "	<td>Pagado a</td>";
            $tabla = $tabla . "	<td>Por concepto de</td>";
            $tabla = $tabla . "	<td>Cierre</td>";

            $tabla = $tabla . "</tr>";

            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $tabla = $tabla . "<tr>";
                $tabla = $tabla . "	<td>$ " . $row['valor'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['pagado_a'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['concepto'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['cierre'] . "</td>";
                $tabla = $tabla . "</tr>";
            }
            $tabla = $tabla . "</table>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
        return $tabla;
    }

}
