<?php

ini_set('display_errors', 'off');
include_once("resources/class.database.php");

class cliente {

    var $id;
    var $cedula;
    var $nombre;
    var $telefono;

    function cliente() {
        
    }

    function select($id) {
        $sql = "SELECT * FROM admin.cliente WHERE id = '$id'";
        try {
            $row = pg::query($sql);
            $row = pg_fetch_array($row);
            $this->id = $row['id'];
            $this->cedula = $row['cedula'];
            $this->nombre = $row['nombre'];
            $this->telefono = $row['telefono'];
            return true;
        } catch (DependencyException $e) {
            
        }
    }

    function delete($id) {
        $sql = "DELETE FROM admin.cliente WHERE id = $id";
        try {
            pg::query("begin");
            $row = pg::query($sql);
            pg::query("commit");
            return "1";
        } catch (DependencyException $e) {
            pg::query("rollback");
            return "-1";
        }
    }

    function insert() {
        if ($this->validaP($this->id) == false) {
            $sql = "INSERT INTO admin.cliente(id, cedula, nombre, telefono) VALUES (" . $this->id . ", '$this->cedula', ' " . $this->nombre . " ', " . $this->telefono . ")";
            try {
                pg::query("begin");
                $row = pg::query($sql);
                pg::query("commit");
                echo "1";
            } catch (DependencyException $e) {
                echo "Error: " . $e;
                pg::query("rollback");
                echo "-1";
            }
        } else {
            $sql = "UPDATE admin.cliente SET id=" . $this->id . ", cedula=' " . $this->cedula . " ', nombre=' " . $this->nombre . " ', telefono=" . $this->telefono . " WHERE id=" . $this->id . "";
            pg::query("begin");
            $row = pg::query($sql);
            pg::query("commit");
            echo "2";
        }
    }

    function validaP($id) {
        $sql = "SELECT * FROM admin.cliente WHERE id = '$id'";
        try {
            $row = pg::query($sql);
            if (pg_num_rows($row) == 0) {
                return false;
            } else {
                return true;
            }
        } catch (DependencyException $e) {
            //pg::query("rollback");
            return false;
        }
    }

    function getTabla() {

        $sql = "SELECT * FROM admin.cliente";
        try {
            echo "<div class='container' style='margin-top: 10px'>";
            echo "<table cellpadding='0' cellspacing='0' border='0' class='table table-striped table-bordered' id='example'>";
            echo "<thead>";
            echo "<tr>";
            echo "	<th>Id</th>";
            echo "	<th>Cedula</th>";
            echo "	<th>Nombre</th>";
            echo "	<th>Teléfono</th>";
            echo "	<th>.</th>";
            echo "</tr>";
            echo "</thead>";
            echo "<tbody>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<tr class='gradeA'>";
                echo "	<th>" . $row['id'] . "</th>";
                echo "	<th>" . $row['cedula'] . "</th>";
                echo "	<th>" . $row['nombre'] . "</th>";
                echo "	<th>" . $row['telefono'] . "</th>";
                echo "	<th><a href='#' class='btn btn-danger' onclick='elimina(\"" . $row['id'] . "\")'><i class='icon-white icon-trash'></i></a>.<a href='#' class='btn btn-primary' onclick='edit(\"" . $row['id'] . "\", \"" . $row['cedula'] . "\",\"" . $row['nombre'] . "\", \"" . $row['telefono'] . "\")'><i class='icon-white icon-refresh'></i></a></th>";
                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
            echo "</div>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
    }

    function getLista() {

        $sql = "SELECT * FROM admin.cliente";
        try {
            echo "<SELECT name='id'>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<OPTION value='" . $row['id'] . "'> " . $row['nombre'] . " </OPTION>";
            }
            echo "</SELECT>";
        } catch (DependencyException $e) {
            pg::query("rollback");
        }
    }

    function getAutocomplete() {
        $res = "";
        $sql = "SELECT * FROM admin.cliente";
        try {
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $res .= ' " ' . $row['id'] . ', ' . $row['cedula'] . ', ' . $row['nombre'] . ', ' . $row['telefono'] . '" ';
                $res .= ',';
            }
            $res = substr($res, 0, -2);
            $res = substr($res, 1);
        } catch (DependencyException $e) {
            
        }
        return $res;
    }

    function getTablaPDF() {

        $sql = "select * from admin.cliente";
        $tabla = "";
        try {
            $tabla = "<table <style> table{background: #F0F0F0 !important; margin-top:40px; width: auto;}
        td{padding: 10px;}tr{padding:20px; }</style>>";
            $tabla = $tabla . "<tr>";
            $tabla = $tabla . "	<td>Id</td>";
            $tabla = $tabla . "	<td>Cedula</td>";
            $tabla = $tabla . "	<td>Nombre</td>";
            $tabla = $tabla . "	<td>Teléfono</td>";
            $tabla = $tabla . "</tr>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $tabla = $tabla . "<tr>";
                $tabla = $tabla . "	<td>" . $row['id'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['cedula'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['nombre'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['telefono'] . "</td>";
                $tabla = $tabla . "</tr>";
            }
            $tabla = $tabla . "</table>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
        return $tabla;
    }

}

?>
