<?php

ini_set('display_errors', 'off');
include_once("resources/class.database.php");

class resultados_examenes {

    var $id_resultado_resultado;
    var $id_resultado_paciente;
    var $fecha;
    var $medico;
    var $especialidad;
    var $fecha_resultado;

    function resultados_examenes() {
        
    }

    function select($id_resultado) {
        $sql = "SELECT * FROM public.resultados_examenes WHERE id_resultado = '$this->id_resultado'";
        try {
            $row = pg::query($sql);
            $row = pg_fetch_array($row);
            $this->id_resultado = $row['id_resultado'];
            $this->id_paciente = $row['id_paciente'];
            $this->fecha = $row['fecha'];
            $this->medico = $row['medico'];
            $this->especialidad = $row['especialidad'];
            $this->fecha_resultado = $row['fecha_resultado'];
            return true;
        } catch (DependencyException $e) {
            
        }
    }

    function delete($id_resultado) {
        $sql = "DELETE FROM public.resultados_examenes WHERE id_resultado = '$id_resultado_resultado'";
        try {
            pg::query("begin");
            $row = pg::query($sql);
            pg::query("commit");
            return "1";
        } catch (DependencyException $e) {
            pg::query("rollback");
            return "-1";
        }
    }

    function insert() {
        if ($this->validaP($this->id_resultado) == false) {
            $sql = "INSERT INTO public.resultados_examenes(id_resultado, id_paciente, fecha, medico, especialidad, fecha_resultado) VALUES (" . $this->id_resultado . ", " . $this->id_paciente . ", '" . $this->fecha . "', '" . $this->medico . "', '" . $this->especialidad . "', '" . $this->fecha_resultado . "')";
            try {
                pg::query("begin");
                $row = pg::query($sql);
                pg::query("commit");
                echo "1";
            } catch (DependencyException $e) {
                echo "Error: " . $e;
                pg::query("rollback");
                echo "-1";
            }
        } else {
            $sql = "UPDATE public.resultados_examenes SET id_resultado=" . $this->id_resultado . ", id_paciente=" . $this->id_paciente . ", fecha='" . $this->fecha . "', medico='" . $this->medico . "', especialidad='". $this->especialidad . "', fecha_resultado='" . $this->fecha_resultado . "' WHERE id_resultado=" . $this->id_resultado . "";
            pg::query("begin");
            $row = pg::query($sql);
            pg::query("commit");
            echo "2";
        }
    }

    function validaP($id_resultado) {
        $sql = "SELECT * FROM public.resultados_examenes WHERE id_resultado = $id_resultado";
        try {
            $row = pg::query($sql);
            if (pg_num_rows($row) == 0) {
                return false;
            } else {
                return true;
            }
        } catch (DependencyException $e) {
            //pg::query("rollback");
            return false;
        }
    }

    function getTabla() {

        $sql = "SELECT * FROM public.resultados_examenes";
        try {
            echo "<div class='container' style='margin-top: 10px'>";
            echo "<table cellpadding='0' cellspacing='0' border='0' class='table table-striped table-bordered' id='example'>";
            echo "<thead>";
            echo "<tr>";
            echo "	<th>Id Resultado</th>";
            echo "	<th>Id Paciente</th>";
            echo "	<th>Fecha</th>";
            echo "	<th>Médico</th>";
            echo "	<th>Especialidad</th>";
            echo "	<th>Fecha resultado</th>";
            echo "	<th>.</th>";
            echo "</tr>";
            echo "</thead>";
            echo "<tbody>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<tr class='gradeA'>";
                echo "	<th>" . $row['id_resultado'] . "</th>";
                echo "	<th>" . $row['id_paciente'] . "</th>";
                echo "	<th>" . $row['fecha'] . "</th>";
                echo "	<th>" . $row['medico'] . "</th>";
                echo "	<th>" . $row['especialidad'] . "</th>";
                echo "	<th>" . $row['fecha_resultado'] . "</th>";
                echo "	<th><a href='#' class='btn btn-danger' onclick='elimina(\"" . $row['id_resultado'] . "\")'><i class='icon-white icon-trash'></i></a>.<a href='#' class='btn btn-primary' onclick='edit(\"" . $row['id_resultado'] . "\", \"" . $row['id_paciente'] . "\",\"" . $row['fecha'] . "\", \"" . $row['medico'] . "\",\"" . $row['especialidad'] . "\", \"" . $row['fecha_resultado'] . "\")'><i class='icon-white icon-refresh'></i></a></th>";
                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
            echo "</div>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
    }

    function getLista() {

        $sql = "SELECT * FROM public.resultados_examenes";
        try {
            echo "<SELECT name='id_resultado'>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<OPTION value='" . $row['id_resultado'] . "'> " . $row['descripcion'] . " </OPTION>";
            }
            echo "</SELECT>";
        } catch (DependencyException $e) {
            pg::query("rollback");
        }
    }

    function getAutocomplete() {
        $res = "";
        $sql = "SELECT * FROM public.resultados_examenes";
        try {
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $res .= '"' . $row['id_resultado'] . ', ' . $row['id_paciente'] . '"';
                $res .= ',';
            }
            $res = substr($res, 0, -2);
            $res = substr($res, 1);
        } catch (DependencyException $e) {
            
        }
        return $res;
    }

    function getTablaPDF() {

        $sql = "select * from public.resultados_examenes";
        $tabla = "";
        try {
            $tabla = "<table <style> table{background: #F0F0F0 !important; margin-top:40px; width: auto;}
        td{padding: 10px;}tr{padding:20px; }</style>>";
            $tabla = $tabla . "<tr>";
            $tabla = $tabla . "	<td>Id Resultado</td>";
            $tabla = $tabla . "	<td>Id Paciente</td>";
            $tabla = $tabla . "	<td>Fecha</td>";
            $tabla = $tabla . "	<td>Médico</td>";
            $tabla = $tabla . "	<td>Especialidad</td>";
            $tabla = $tabla . "	<td>Fecha resultado</td>";

            $tabla = $tabla . "</tr>";

            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $tabla = $tabla . "<tr>";
                $tabla = $tabla . "	<td>" . $row['id_resultado'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['id_paciente'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['fecha'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['medico'] . "</td>";
                $tabla = $tabla . "	<td>$ " . $row['especialidad'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['fecha_resultado'] . "</td>";
                $tabla = $tabla . "</tr>";
            }
            $tabla = $tabla . "</table>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
        return $tabla;
    }

    function getTablaInforme() {

        $sql = "(select especialidad, id, fecha from public.resultados_examenes) order by 1 desc";
        try {
            echo "<div class='container' style='margin-top: 10px'>";
            echo "<table>";
            echo "<thead>";
            echo "<tr>";
            echo "	<th>Especialidad</th>";
            echo "	<th>Id Empleado</th>";
            echo "	<th>Fecha resultado</th>";
       
            echo "</tr>";
            echo "</thead>";
            echo "<tbody>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<tr class='gradeA'>";
                echo "	<th>" . $row['especialidad'] . "</th>";
                echo "	<th>" . $row['id_resultado'] . "</th>";
                echo "	<th>" . $row['fecha'] . "</th>";
                           
                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
            echo "</div>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
    }
    
    function getTablaInformePDF() {

        $sql = "(select especialidad, id, fecha from public.resultados_examenes) order by 1 desc";
        $tabla = "";
        try {
            $tabla = "<table <style> table{background: #F0F0F0 !important; margin-top:40px; width: auto;}
        td{padding: 10px;}tr{padding:20px; }</style>>";
            $tabla = $tabla . "<tr>";
            $tabla = $tabla . "	<td>Especialidad</td>";
            $tabla = $tabla . "	<td>Id Resultado</td>";
            $tabla = $tabla . "	<td>Fecha</td>";
                      $tabla = $tabla . "</tr>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $tabla = $tabla . "<tr>";
                $tabla = $tabla . "	<td>" . $row['especialidad'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['id_resultado'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['fecha'] . "</td>";
               
                $tabla = $tabla . "</tr>";
            }
            $tabla = $tabla . "</table>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
        return $tabla;
    }

}
