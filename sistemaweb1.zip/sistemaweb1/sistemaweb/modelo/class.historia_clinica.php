<?php

ini_set('display_errors', 'on');
include_once("resources/class.database.php");

class historia_clinica {

    var $id_historia;
    var $id_paciente;
    var $fecha;
    var $medicos;
    var $especialidades;
    var $tratamientos;

    function historia_clinica() {
        
    }

    function insert() {
        if ($this->validaP($this->id_historia) == false) {
            $sql = "INSERT INTO public.historia_clinica(id_historia,id_paciente,fecha,medicos,especialidades,tratamientos)VALUES (" . $this->id_historia . "," . $this->id_paciente . ",'" . $this->fecha . "','" . $this->medicos . "','" . $this->especialidades . "','" . $this->tratamientos . "')";
            try {
                pg::query("begin");
                $row = pg::query($sql);

                pg::query("commit");
                return "1";
            } catch (DependencyException $e) {
                echo "Error: " . $e;
                pg::query("rollback");
                return "-1";
            }
        } else {
            $sql = "UPDATE public.historia_clinica SET id_historia=" . $this->id_historia . ", id_paciente=" . $this->id_paciente . ",fecha='" . $this->fecha . "', medicos='" . $this->medicos . "',especialidades='" . $this->especialidades . "', tratamientos='" . $this->tratamientos . "' WHERE  id_historia=" . $this->id_historia . "";

            pg::query("begin");
            $row = pg::query($sql);
            pg::query("commit");
            return "2";
        }
    }

    function validaP($id_historia) {
        $sql = "SELECT * FROM public.historia_clinica WHERE id_historia=$id_historia";
        try {
            $row = pg::query($sql);
            if (pg_num_rows($row) == 0) {
                return false;
            } else {
                return true;
            }
        } catch (DependencyException $e) {
            return false;
        }
    }

    function select($id_historia) {
        $sql = "SELECT * FROM public.historia_clinica WHERE id_historia = $id_historia";
        try {
            $row = pg::query($sql);
            if (pg_num_rows($row) == 0) {
                return "-1";
            }
            $row = pg_fetch_array($row);
            $this->id_historia = $row['id_historia'];
            $this->id_paciente = $row['id_paciente'];
            $this->fecha = $row['fecha'];
            $this->medicos = $row['medicos'];
            $this->especialidades = $row['especialidades'];
            $this->tratamientos = $row['tratamientos'];
            return $this->descripcion;
        } catch (DependencyException $e) {
            
        }
    }

    function delete($id_historia) {
        if ($this->validaP($id_historia) == true) {
            $sql = "DELETE FROM public.historia_clinica WHERE id_historia = '$id_historia'";
            try {
                pg::query("begin");
                $row = pg::query($sql);
                pg::query("commit");
                return "1";
            } catch (DependencyException $e) {
                pg::query("rollback");
                return "-1";
            }
        } else {
            return "-2";
        }
    }

    function getTCombo() {

        $sql = "SELECT * FROM public.historia_clinica";
        try {
            echo "<SELECT name='historia_clinica'>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<OPTION value='" . $row['id_paciente'] . "'> " . $row['id_historia'] . $row['medicos'] . "'> " . $row['fecha'] . $row['tratamientos'] . "'> " . $row['especialidades'] . " </OPTION>";
            }
            echo "</SELECT>";
        } catch (DependencyException $e) {
            pg::query("rollback");
        }
    }

    function getTabla() {

        $sql = "SELECT * FROM public.historia_clinica";
        try {
            echo "<div class='container' style='margin-top: 10px'>";
            echo "<table cellpadding='0' cellspacing='0' border='0' class='table table-striped table-bordered' id='example'>";
            echo "<thead>";
            echo "<tr>";
            echo "	<th>Id Historia Clinica</th>";
            echo "	<th>Id Paciente</th>";
            echo "	<th>Fecha</th>";
            echo "	<th>Médicos</th>";
            echo "	<th>Especialidades</th>";
            echo "	<th>Tratamientos</th>";
            echo "	<th>.</th>";
            echo "</tr>";
            echo "</thead>";
            echo "<tbody>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<tr class='gradeA'>";
                echo "	<th>" . $row['id_paciente'] . "</th>";
                echo "	<th>" . $row['id_historia'] . "</th>";
                echo "	<th>" . $row['medicos'] . "</th>";
                echo "	<th>" . $row['fecha'] . "</th>";
                echo "	<th>" . $row['especialidades'] . "</th>";
                echo "	<th>" . $row['tratamientos'] . "</th>";
                echo "	<th><a href='#' class='btn btn-danger' onclick='elimina(\"" . $row['id_historia'] . "\")'><i class='icon-white icon-trash'></i></a>.<a href='#' class='btn btn-primary' onclick='edit(\"" . $row['id_paciente'] . "\", \"" . $row['id_historia'] . "\",\"" . $row['medicos'] . "\", \"" . $row['fecha'] . "\",\"" . $row['tratamientos'] . "\", \"" . $row['especialidades'] . "\")'><i class='icon-white icon-refresh'></i></a></th>";
                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
            echo "</div>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
    }

    function getLista() {

        $sql = "SELECT * FROM public.historia_clinica";
        try {
            echo "<SELECT name='id_historia'>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<OPTION value='" . $row['id_historia'] . "'> " . $row['id_historia'] . " </OPTION>";
            }
            echo "</SELECT>";
        } catch (DependencyException $e) {
            pg::query("rollback");
        }
    }

    function getAutocomplete() {
        $res = "";
        $sql = "SELECT * FROM public.historia_clinica";
        try {
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $res .= '"' . $row['id_historia'] . ', ' . $row['id_paciente'] . ',' . $row['fecha'] . ', ' . $row['medicos'] . ',' . $row['especialidades'] . ', ' . $row['tratamientos'] . '"';
                $res .= ',';
            }
            $res = substr($res, 0, -2);
            $res = substr($res, 1);
        } catch (DependencyException $e) {
            
        }
        return $res;
    }

    function getTablaPDF() {

        $sql = "select * from public.historia_clinica";
        $tabla = "";
        try {
            $tabla = "<table <style> table{background: #F0F0F0 !important; margin-top:40px; width: auto;}
        td{padding: 10px;}tr{padding:20px; }</style>>";

            $tabla = $tabla . "<tr>";
            $tabla = $tabla . "	<td>Id Historia Clinica  </td>";
            $tabla = $tabla . "	<td>Id Paciente</td>";
            $tabla = $tabla . "	<td>Fecha  </td>";
            $tabla = $tabla . "	<td>Médicos</td>";
            $tabla = $tabla . "	<td>Especialidades  </td>";
            $tabla = $tabla . "	<td>Tratamientos</td>";
            $tabla = $tabla . "</tr>";

            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $tabla = $tabla . "<tr>";
                $tabla = $tabla . "	<td>" . $row['id_paciente'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['id_historia'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['fecha'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['medicos'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['tratamientos'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['especialidades'] . "</td>";
                $tabla = $tabla . "</tr>";
            }
            $tabla = $tabla . "</table>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
        return $tabla;
    }

}

?>
