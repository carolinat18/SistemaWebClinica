<?php

ini_set('display_errors', 'on');
include_once("resources/class.database.php");

class citas {

    var $id_cita;
    var $id_paciente;
    var $medico;
    var $especialidad;
    var $fecha_hora;
    var $direccion_cita;

    function citas() {
        
    }

    function select($id_cita) {
        $sql = "SELECT * FROM public.citas WHERE id_cita = $id_cita";
        try {
            $row = pg::query($sql);
            $row = pg_fetch_array($row);
            $this->id_cita = $row['id_cita'];
            $this->id_paciente = $row['id_paciente'];
            $this->medico = $row['medico'];
            $this->especialidad = $row['especialidad'];
            $this->fecha_hora = $row['fecha_hora'];
            $this->direccion_cita = $row['direccion_cita'];
            return true;
        } catch (DependencyException $e) {
            
        }
    }

    function insert() {

        $sql = "INSERT INTO public.citas(id_cita, id_paciente, medico, especialidad,fecha_hora, direccion_cita) VALUES (" . $this->id_cita . "," . $this->id_paciente . ", '" . $this->medico . "', '" . $this->especialidad . "', '" . $this->fecha_hora . "', '" . $this->direccion_cita . "')";
        try {
            pg::query("begin");
            $row = pg::query($sql);
            pg::query("commit");
            echo "1";
        } catch (DependencyException $e) {
            echo "Error: " . $e;
            pg::query("rollback");
            echo "-1";
        }
    }

    function getTabla() {

        $sql = "select * 
from public.citas
--where public.citas.medico = public.empleado.id";
        try {
            echo "<div class='container' style='margin-top: 10px'>";
            echo "<table cellpadding='0' cellspacing='0' border='0' class='table table-striped table-bordered' id='example'>";
            echo "<thead>";
            echo "<tr>";
            echo "	<th>Id Cita</th>";
            echo "	<th>Id Paciente</th>";
            echo "	<th>Médico</th>";
            echo "	<th>Especialidad</th>";
            echo "	<th>Fecha y hora</th>";
            echo "	<th>Dirección cita</th>";
            echo "</tr>";
            echo "</thead>";
            echo "<tbody>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<tr class='gradeA'>";
                echo "	<th>" . $row['id_cita'] . "</th>";
                echo "	<th>" . $row['id_paciente'] . "</th>";
                echo "	<th>" . $row['medico'] . "</th>";
                echo "	<th>" . $row['especialidad'] . "</th>";
                echo "	<th>" . $row['fecha_hora'] . "</th>";
                echo "	<th>" . $row['direccion_cita'] . "</th>";
                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
            echo "</div>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
    }

//    function getEspecialidadAcumulado() {
//
//        $sql = "select sum(especialidad) from public.citas";
//        try {
//            echo "<div class='container' style='margin-top: 10px'>";
//            echo "<table cellpadding='0' cellspacing='0' border='0' class='table table-striped table-bordered' id='example'>";
//            echo "<thead>";
//            echo "<tr>";
//            echo "	<th>Ingresos: Especialidad acumulado</th>";
//
//            echo "</tr>";
//            echo "</thead>";
//            echo "<tbody>";
//            $result = pg::query($sql);
//            while ($row = pg_fetch_array($result)) {
//                echo "<tr class='gradeA'>";
//                echo "	<th>$ " . $row['sum'] . "</th>";
//
//                echo "</tr>";
//            }
//            echo "</tbody>";
//            echo "</table>";
//            echo "</div>";
//        } catch (DependencyException $e) {
//            echo "Procedimiento sql invalido en el servidor";
//        }
//    }
//    function getTablaEspecialidadMayor() {
//
//        $sql = "select id_cita, id_paciente, medico, especialidad
//from public.citas, public.empleado
//where public.citas.medico = public.empleado.id and especialidad=(select MAX(especialidad)
//  from public.citas)";
//        try {
//            echo "<div class='container' style='margin-top: 10px'>";
//            echo "<table cellpadding='0' cellspacing='0' border='0' class='table table-striped table-bordered' id='example'>";
//            echo "<thead>";
//            echo "<tr>";
//            echo "	<th>Id citas</th>";
//            echo "	<th>Id Paciente</th>";
//            echo "	<th>Médico</th>";
//            echo "	<th>Especialidad</th>";
//            echo "</tr>";
//            echo "</thead>";
//            echo "<tbody>";
//            $result = pg::query($sql);
//            while ($row = pg_fetch_array($result)) {
//                echo "<tr class='gradeA'>";
//                echo "	<th>" . $row['id_cita'] . "</th>";
//                echo "	<th>" . $row['id_paciente'] . "</th>";
//                echo "	<th>" . $row['medico'] . "</th>";
//                echo "	<th>$ " . $row['especialidad'] . "</th>";
//                echo "</tr>";
//            }
//            echo "</tbody>";
//            echo "</table>";
//            echo "</div>";
//        } catch (DependencyException $e) {
//            echo "Procedimiento sql invalido en el servidor";
//        }
//    }
//    function getTablaEspecialidadMenor() {
//
//        $sql = "select id_cita, id_paciente, medico, especialidad,fecha_hora, direccion_cita
//from public.citas, public.empleado
//  from public.citas)";
//        try {
//            echo "<div class='container' style='margin-top: 10px'>";
//            echo "<table cellpadding='0' cellspacing='0' border='0' class='table table-striped table-bordered' id='example'>";
//            echo "<thead>";
//            echo "<tr>";
//            echo "	<th>Id citas</th>";
//            echo "	<th>Id Paciente</th>";
//            echo "	<th>Médico</th>";
//            echo "	<th>Especialidad</th>";
//            echo "	<th>Fecha y hora</th>";
//            echo "	<th>Especialidad1</th>";
//            echo "</tr>";
//            echo "</thead>";
//            echo "<tbody>";
//            $result = pg::query($sql);
//            while ($row = pg_fetch_array($result)) {
//                echo "<tr class='gradeA'>";
//                echo "	<th>" . $row['id_cita'] . "</th>";
//                echo "	<th>" . $row['id_paciente'] . "</th>";
//                echo "	<th>" . $row['medico'] . "</th>";
//                echo "	<th>" . $row['especialidad'] . "</th>";
//                echo "	<th>" . $row['fecha_hora'] . "</th>";
//                echo "	<th>" . $row['direccion_cita'] . "</th>";
//                echo "</tr>";
//            }
//            echo "</tbody>";
//            echo "</table>";
//            echo "</div>";
//        } catch (DependencyException $e) {
//            echo "Procedimiento sql invalido en el servidor";
//        }
//    }

    function getLista() {

        $sql = "SELECT * FROM public.citas";
        try {
            echo "<SELECT name='id_cita'>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<OPTION value='" . $row['id_cita'] . "'> " . $row['id_paciente'] . "." . $row['medico'] . "." . $row['especialidad'] . "." . $row['fecha_hora'] . "." . $row['direccion_cita'] . " </OPTION>";
            }
            echo "</SELECT>";
        } catch (DependencyException $e) {
            pg::query("rollback");
        }
    }

    function getAutocomplete() {
        $res = "";
        $sql = "SELECT * FROM public.citas";
        try {
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $res .= '"' . $row['id_cita'] . ', ' . $row['id_paciente'] . '"' . '"' . $row['medico'] . ', ' . $row['especialidad'] . '"' . '"' . $row['fecha_hora'] . ', ' . $row['direccion_cita'] . '"';
                $res .= ',';
            }
            $res = substr($res, 0, -2);
            $res = substr($res, 1);
        } catch (DependencyException $e) {
            
        }
        return $res;
    }

//    function getComboBox() {
//
//        $sql = "SELECT * FROM public.empleado";
//        try {
//            echo "<SELECT name='medico' id='medico'>";
//            //pg::query("begin");
//            $result = pg::query($sql);
//            //pg::query("commit");
//            while ($row = pg_fetch_array($result)) {
//                echo "<OPTION value='" . $row['id_cita'] . "'> " . $row['medico'] . "." . $row['medico'] . "." . $row['medico'] . "." . $row['medico'] . "." . $row['medico'] . " </OPTION>";
//            }
//            echo "</SELECT>";
//        } catch (DependencyException $e) {
//            pg::query("rollback");
//        }
//    }
//    function consultaid_paciente($medico, $especialidad) {
//        $sql = "select SUM(especialidad) as sumatoria from public.citas where (id_paciente>TO_DATE('$medico','dd/mm/yyyy') and id_paciente<TO_DATE('$especialidad','dd/mm/yyyy'))";
//        try {
//            echo "<div class='container' style='margin-top: 10px'>";
//            echo "<table cellpadding='0' cellspacing='0' border='0' class='table table-striped table-bordered' id='example'>";
//            echo "<thead>";
//            echo "<tr>";
//            echo "	<th>Sumatoria</th>";
//
//            echo "</thead>";
//            echo "<tbody>";
//            $result = pg::query($sql);
//            while ($row = pg_fetch_array($result)) {
//                echo "<tr class='gradeA'>";
//                echo "	<th>" . $row['sumatoria'] . "</th>";
//
//                echo "</tr>";
//            }
//            echo "</tbody>";
//            echo "</table>";
//            echo "</div>";
//        } catch (DependencyException $e) {
//            echo "Procedimiento sql invalido en el servidor";
//        }
//    }

    function getTablaPDF() {

        $sql = "select * 
from public.citas
--where public.citas.medico = public.empleado.id";
        $tabla = "";
        try {
            $tabla = "<table <style> table{background: #F0F0F0 !important; margin-top:40px; width: auto;}
        td{padding: 10px;}tr{padding:20px; }</style>>";
            $tabla = $tabla . "<tr>";
            $tabla = $tabla . "	<td>Id Cita</td>";
            $tabla = $tabla . "	<td>Id Paciente</td>";
            $tabla = $tabla . "	<td>Médico</td>";
            $tabla = $tabla . "	<td>Especialidad</td>";
            $tabla = $tabla . "	<td>Fecha y hora</td>";
            $tabla = $tabla . "	<td>Dirección cita</td>";
            $tabla = $tabla . "</tr>";

            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $tabla = $tabla . "<tr>";
                $tabla = $tabla . "	<td>" . $row['id_cita'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['id_paciente'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['medico'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['especialidad'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['fecha_hora'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['direccion_cita'] . "</td>";
                $tabla = $tabla . "</tr>";
            }
            $tabla = $tabla . "</table>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
        return $tabla;
    }

//    function getEspecialidadMayorPDF() {
//
//        $sql = "select id_cita, id_paciente, medico, especialidad
//from public.citas, public.empleado
//where public.citas.medico = public.empleado.id and especialidad=(select MAX(especialidad)
//  from public.citas)";
//        $tabla = "";
//        try {
//            $tabla = "<table <style> table{background: #F0F0F0 !important; margin-top:40px; width: auto;}
//        td{padding: 10px;}tr{padding:20px; }</style>>";
//            $tabla = $tabla . "<tr>";
//            $tabla = $tabla . "	<td>Id Cita</td>";
//            $tabla = $tabla . "	<td>Id Paciente</td>";
//            $tabla = $tabla . "	<td>Médico</td>";
//            $tabla = $tabla . "	<td>Especialidad</td>";
//
//            $tabla = $tabla . "</tr>";
//
//            $result = pg::query($sql);
//            while ($row = pg_fetch_array($result)) {
//                $tabla = $tabla . "<tr>";
//                $tabla = $tabla . "	<td>" . $row['id_cita'] . "</td>";
//                $tabla = $tabla . "	<td>" . $row['id_paciente'] . "</td>";
//                $tabla = $tabla . "	<td>" . $row['medico'] . "</td>";
//                $tabla = $tabla . "	<td>$ " . $row['especialidad'] . "</td>";
//                $tabla = $tabla . "</tr>";
//            }
//            $tabla = $tabla . "</table>";
//        } catch (DependencyException $e) {
//            echo "Procedimiento sql invalido en el servidor";
//        }
//        return $tabla;
//    }

//    function getEspecialidadMenorPDF() {
//
//        $sql = "select id_cita, id_paciente, medico, especialidad
//from public.citas, public.empleado
//where public.citas.medico = public.empleado.id and especialidad=(select MIN(especialidad)
//  from public.citas)";
//        $tabla = "";
//        try {
//            $tabla = "<table <style> table{background: #F0F0F0 !important; margin-top:40px; width: auto;}
//        td{padding: 10px;}tr{padding:20px; }</style>>";
//            $tabla = $tabla . "<tr>";
//            $tabla = $tabla . "	<td>Id Cita</td>";
//            $tabla = $tabla . "	<td>Id Paciente</td>";
//            $tabla = $tabla . "	<td>Médico</td>";
//            $tabla = $tabla . "	<td>Especialidad</td>";
//
//            $tabla = $tabla . "</tr>";
//
//            $result = pg::query($sql);
//            while ($row = pg_fetch_array($result)) {
//                $tabla = $tabla . "<tr>";
//                $tabla = $tabla . "	<td>" . $row['id_cita'] . "</td>";
//                $tabla = $tabla . "	<td>" . $row['id_paciente'] . "</td>";
//                $tabla = $tabla . "	<td>" . $row['medico'] . "</td>";
//                $tabla = $tabla . "	<td>$ " . $row['especialidad'] . "</td>";
//                $tabla = $tabla . "</tr>";
//            }
//            $tabla = $tabla . "</table>";
//        } catch (DependencyException $e) {
//            echo "Procedimiento sql invalido en el servidor";
//        }
//        return $tabla;
//    }

//    function getEspecialidadAcumuladoPDF() {
//
//        $sql = "select sum(especialidad) from public.citas";
//        $tabla = "";
//        try {
//            $tabla = "<table <style> table{background: #F0F0F0 !important; margin-top:40px; width: auto;}
//        td{padding: 10px;}tr{padding:20px; }</style>>";
//            $tabla = $tabla . "<tr>";
//            $tabla = $tabla . "	<td>Ingresos: Especialidad acumulado</td>";
//            $tabla = $tabla . "</tr>";
//            $result = pg::query($sql);
//            while ($row = pg_fetch_array($result)) {
//                $tabla = $tabla . "<tr>";
//                $tabla = $tabla . "	<td>" . $row['sum'] . "</td>";
//                $tabla = $tabla . "</tr>";
//            }
//            $tabla = $tabla . "</table>";
//        } catch (DependencyException $e) {
//            echo "Procedimiento sql invalido en el servidor";
//        }
//        return $tabla;
//    }
}
