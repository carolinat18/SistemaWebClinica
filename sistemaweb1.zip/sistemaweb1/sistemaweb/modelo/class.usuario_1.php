<?php
ini_set('display_errors', 'on');
include_once("conexion/class.database.php");

class usuario {

    var $id;
    var $usuario;
    var $password;

    function usuario() {
        
    }

    function validaLogin($usuario, $password) {
        $sql = "SELECT * FROM public.usuario WHERE usuario = '$usuario' and password ='$password'";
        try {
            $row = pg::query($sql); // Ejecuta la consulta SQL
            if (pg_num_rows($row) == 0) { // Cuenta cuantos registros regresó
                return false;
            } else {
                return true;
            }
        } catch (DependencyException $e) {
            return false;
        }
    }
    
   function valide($usuario, $password){
      $sql =  "SELECT * FROM public.usuario WHERE usuario = '$usuario' AND password = '$password'";
      try {
	$row = pg::query($sql); // Ejecuta la consulta SQL
	if(pg_num_rows($row) == 0){ // Cuenta cuantos registros regresó	
		return "denegar";
        }
	else{
		$row=pg_fetch_array($row);
		
		return "permitir";
	}
	}
	catch (DependencyException $e) {
		return false;
	}
}

    function insert() {
        if ($this->validaP($this->usuario) == false) {
            $sql = "INSERT INTO public.usuario(usuario, password)VALUES ( '" .$this->usuario ."', '" .$this->password ."')";

            try {
                pg::query("begin");
                $row = pg::query($sql);

                pg::query("commit");
                return "1";
            } catch (DependencyException $e) {
                echo "Error: " . $e;
                pg::query("rollback");
                return "-1";
            }
        } else {
            $sql = "UPDATE public.usuario SET usuario='".$this->usuario."', password='".$this->password ."' WHERE usuario=".$this->usuario."";
            pg::query("begin");
            $row = pg::query($sql);
            pg::query("commit");
            return "2";
        }
    }

    function validaP($usuario) {
        $sql = "SELECT * FROM public.usuario WHERE usuario='$usuario'";
        try {
            $row = pg::query($sql);
            if (pg_num_rows($row) == 0) {
                return false;
            } else {
                return true;
            }
        } catch (DependencyException $e) {
            return false;
        }
    }

    function delete($usuario) {
        if ($this->validaP($id) == true) {
            $sql = "DELETE FROM public.usuario WHERE usuario = $usuario";
            try {
                pg::query("begin");
                $row = pg::query($sql);
                pg::query("commit");
                return "1";
            } catch (DependencyException $e) {
                pg::query("rollback");
                return "-1";
            }
        } else {
            return "-2";
        }
    }

    function getTabla() {

        $sql = "SELECT * FROM public.usuario";
        try {
            echo "<div class='container' style='margin-top: 10px'>";
            echo "<table cellpadding='0' cellspacing='0' border='0' class='table table-striped table-bordered' id='example'>";
            echo "<thead>";
            echo "<tr>";
       //     echo "	<th>Id</th>";
            echo "	<th>Nombre de usuario</th>";
            echo "	<th>Contraseña</th>";

            echo "	<th>.</th>";
            echo "</tr>";
            echo "</thead>";
            echo "<tbody>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<tr class='gradeA'>";
    //            echo "	<th>" . $row['id'] . "</th>";
                echo "	<th>" . $row['usuario'] . "</th>";
                echo "	<th>" . $row['pas'] . "</th>";

                echo "	<th><a href='#' class='btn btn-danger' onclick='elimina(\"" . $row['usuario'] . "\")'><i class='icon-white icon-trash')></i></a>.<a href='#' class='btn btn-primary' onclick='edit( \"" . $row['usuario'] . "\", \"" . $row['pas'] . "\")'><i class='icon-white icon-refresh'></i></a></th>";
                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
            echo "</div>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
    }

}
