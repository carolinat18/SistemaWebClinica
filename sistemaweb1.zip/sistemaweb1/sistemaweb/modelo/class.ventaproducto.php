<?php

ini_set('display_errors', 'off');
include_once("resources/class.database.php");

class ventaproducto {

    var $idproducto;
    var $idventa;
    var $cantidad;
    var $fecha;

    function ventaproducto() {
        
    }

    function select($idventa) {
        $sql = "SELECT * FROM admin.ventaproducto WHERE idventa = $idventa";
        try {
            $row = pg::query($sql);
            $row = pg_fetch_array($row);
            $this->idproducto = $row['idproducto'];
            $this->idventa = $row['idventa'];
            $this->cantidad = $row['cantidad'];
            $this->fecha = $row['fecha'];
            return true;
        } catch (DependencyException $e) {
            
        }
    }

      function insert() {
                    $sql = "INSERT INTO admin.ventaproducto(idproducto, idventa, cantidad, fecha) VALUES (" . $this->idproducto . ", " . $this->idventa . ", " . $this->cantidad . ", ' " . $this->fecha . " ')";
            try {
                pg::query("begin");
                $row = pg::query($sql);
                pg::query("commit");
                echo "1";
            } catch (DependencyException $e) {
                echo "Error: " . $e;
                pg::query("rollback");
                echo "-1";
            }
           }

     function getTabla() {

        $sql = "select  distinct idproducto, ventaproducto.idventa, ventaproducto.cantidad, descripcion, ventaproducto.fecha
from admin.ventaproducto, admin.producto, admin.venta 
where admin.producto.id=admin.ventaproducto.idproducto";
        try {
            echo "<div class='container' style='margin-top: 10px'>";
            echo "<table cellpadding='0' cellspacing='0' border='0' class='table table-striped table-bordered' id='example'>";
            echo "<thead>";
            echo "<tr>";
            echo "	<th>Id venta</th>";
            echo "	<th>Id Producto</th>";
            echo "	<th>Cantidad</th>";
            echo "	<th>Fecha</th>";
                 echo "</tr>";
            echo "</thead>";
            echo "<tbody>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<tr class='gradeA'>";
                echo "	<th>" . $row['idventa'] . "</th>";
                echo "	<th>" . $row['descripcion'] . "</th>";
                echo "	<th>" . $row['cantidad'] . "</th>";
                echo "	<th>" . $row['fecha'] . "</th>";
                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
            echo "</div>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
    }

    function getProductomasVendido() {

        $sql = "(select  SUM(cantidad) as Totalventas,idproducto from admin.ventaproducto group by idproducto)order by 1 desc";
        try {
            echo "<div class='container' style='margin-top: 10px'>";
            echo "<table cellpadding='0' cellspacing='0' border='0' class='table table-striped table-bordered' id='example'>";
            echo "<thead>";
            echo "<tr>";
            echo "	<th>Total ventas</th>";
            echo "	<th>Id Producto</th>";

            echo "	<th>.</th>";
            echo "</tr>";
            echo "</thead>";
            echo "<tbody>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<tr class='gradeA'>";
                echo "	<th>" . $row['totalventas'] . "</th>";
                echo "	<th>" . $row['idproducto'] . "</th>";


                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
            echo "</div>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
    }

    function getLista() {

        $sql = "SELECT * FROM admin.ventaproducto";
        try {
            echo "<SELECT name=idventa>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<OPTION value='" . $row['idventa'] . "'> " . $row['fecha'] . " </OPTION>";
            }
            echo "</SELECT>";
        } catch (DependencyException $e) {
            pg::query("rollback");
        }
    }

    function getAutocomplete() {
        $res = "";
        $sql = "SELECT * FROM admin.ventaproducto";
        try {
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $res .= ' " ' . $row['idventa'] . ', ' . $row['idproducto'] . ',' . $row['cantidad'] . ', ' . $row['fecha'] . ' " ';
                $res .= ',';
            }
            $res = substr($res, 0, -2);
            $res = substr($res, 1);
        } catch (DependencyException $e) {
            
        }
        return $res;
    }

    function getComboBoxV() {

        $sql = "SELECT * FROM admin.venta";
        try {
            echo "<SELECT name='idventa' id='idventa'>";
            //pg::query("begin");
            $result = pg::query($sql);
            //pg::query("commit");
            while ($row = pg_fetch_array($result)) {
                echo "<OPTION value='" . $row['idventa'] . "'> " . $row['idventa'] . " </OPTION>";
            }
            echo "</SELECT>";
        } catch (DependencyException $e) {
            pg::query("rollback");
        }
    }

    function getComboBoxP() {

        $sql = "SELECT * FROM admin.producto";
        try {
            echo "<SELECT name='idproducto' id='idproducto'>";
            //pg::query("begin");
            $result = pg::query($sql);
            //pg::query("commit");
            while ($row = pg_fetch_array($result)) {
                echo "<OPTION value='" . $row['id'] . "'> " . $row['descripcion'] . " </OPTION>";
            }
            echo "</SELECT>";
        } catch (DependencyException $e) {
            pg::query("rollback");
        }
    }

    function getTablaPDF() {

        $sql = "select  distinct idproducto, ventaproducto.idventa, ventaproducto.cantidad, descripcion, ventaproducto.fecha
from admin.ventaproducto, admin.producto, admin.venta 
where admin.producto.id=admin.ventaproducto.idproducto";
        $tabla = "";
        try {
            $tabla = "<table <style> table{background: #F0F0F0 !important; margin-top:40px; width: auto;}
        td{padding: 10px;}tr{padding:20px; }</style>>";
            $tabla = $tabla . "<tr>";
            $tabla = $tabla . "	<td>Producto</td>";
            $tabla = $tabla . "	<td>Id venta</td>";
            $tabla = $tabla . "	<td>Cantidad</td>";
            $tabla = $tabla . "	<td>Fecha</td>";

            $tabla = $tabla . "</tr>";

            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $tabla = $tabla . "<tr>";
                $tabla = $tabla . "	<td>" . $row['descripcion'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['idventa'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['cantidad'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['fecha'] . "</td>";
                $tabla = $tabla . "</tr>";
            }
            $tabla = $tabla . "</table>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
        return $tabla;
    }

    function getProductomasVendidoPDF() {

        $sql = "(select  SUM(cantidad) as Totalventas,idproducto from admin.ventaproducto group by idproducto)order by 1 desc";
        $tabla = "";
        try {
            $tabla = "<table <style> table{background: #F0F0F0 !important; margin-top:40px; width: auto;}
        td{padding: 10px;}tr{padding:20px; }</style>>";
            $tabla = $tabla . "<tr>";
            $tabla = $tabla . "	<td>Total ventas</td>";
            $tabla = $tabla . "	<td>Id producto</td>";
                       $tabla = $tabla . "</tr>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $tabla = $tabla . "<tr>";
                $tabla = $tabla . "	<td>" . $row['totalventas'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['idproducto'] . "</td>";
                               $tabla = $tabla . "</tr>";
            }
            $tabla = $tabla . "</table>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
        return $tabla;
    }
}

?>
