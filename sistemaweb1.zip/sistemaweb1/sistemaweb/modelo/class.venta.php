<?php

ini_set('display_errors', 'off');
include_once("resources/class.database.php");

class venta {

    var $id;
    var $cliente;

    function venta() {
        
    }

    function select($id) {
        $sql = "SELECT * FROM admin.venta WHERE idventa = $id";
        try {
            $row = pg::query($sql);
            $row = pg_fetch_array($row);
            $this->id = $row['idventa'];
            $this->cliente = $row['cliente'];
            return true;
        } catch (DependencyException $e) {
            
        }
    }

    function insert() {

        $sql = "INSERT INTO admin.venta( idventa, cliente) VALUES ( '$this->id', '$this->cliente')";
        try {
            pg::query("begin");
            $row = pg::query($sql);
            pg::query("commit");
            echo "1";
        } catch (DependencyException $e) {
            echo "Error: " . $e;
            pg::query("rollback");
            echo "-1";
        }
    }

    function getTablaClientes() {

        $sql = "(select  count(*) as Totalventas, cliente from admin.venta group by cliente)  order  by 1 desc";
        try {
            echo "<div class='container' style='margin-top: 10px'>";
            echo "<table cellpadding='0' cellspacing='0' border='0' class='table table-striped table-bordered' id='example'>";
            echo "<thead>";
            echo "<tr>";
            echo "	<th>Número de compras</th>";
            echo "	<th>Id Cliente</th>";

            echo "</tr>";
            echo "</thead>";
            echo "<tbody>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<tr class='gradeA'>";
                echo "	<th>" . $row['totalventas'] . "</th>";
                echo "	<th>" . $row['cliente'] . "</th>";

                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
            echo "</div>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
    }

    function getTabla() {

        $sql = "select * 
from admin.venta, admin.cliente
where admin.venta.cliente = admin.cliente.id";
        try {
            echo "<div class='container' style='margin-top: 10px'>";
            echo "<table cellpadding='0' cellspacing='0' border='0' class='table table-striped table-bordered' id='example'>";
            echo "<thead>";
            echo "<tr>";
            echo "	<th>Id Venta</th>";
            echo "	<th>Cliente</th>";
            echo "</tr>";
            echo "</thead>";
            echo "<tbody>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<tr class='gradeA'>";
                echo "	<th>" . $row['idventa'] . "</th>";
                echo "	<th>" . $row['nombre'] . "</th>";
                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
            echo "</div>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
    }

    function getLista() {

        $sql = "SELECT * FROM admin.venta";
        try {
            echo "<SELECT name='idventa'>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<OPTION value='" . $row['idventa'] . "'> " . $row['cliente'] . " </OPTION>";
            }
            echo "</SELECT>";
        } catch (DependencyException $e) {
            pg::query("rollback");
        }
    }

    function getAutocomplete() {
        $res = "";
        $sql = "SELECT * FROM admin.venta";
        try {
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $res .= '"' . $row['idventa'] . ', ' . $row['cliente'] . '"';
                $res .= ',';
            }
            $res = substr($res, 0, -2);
            $res = substr($res, 1);
        } catch (DependencyException $e) {
            
        }
        return $res;
    }

    function getComboBox() {

        $sql = "SELECT * FROM admin.cliente";
        try {
            echo "<SELECT name='cliente' id='cliente'>";
            //pg::query("begin");
            $result = pg::query($sql);
            //pg::query("commit");
            while ($row = pg_fetch_array($result)) {
                echo "<OPTION value='" . $row['id'] . "'> " . $row['nombre'] . " </OPTION>";
            }
            echo "</SELECT>";
        } catch (DependencyException $e) {
            pg::query("rollback");
        }
    }

    function getTablaPDF() {

        $sql = "select * 
from admin.venta, admin.cliente
where admin.venta.cliente = admin.cliente.id";
        $tabla = "";
        try {
            $tabla = "<table <style> table{background: #F0F0F0 !important; margin-top:40px; width: auto;}
        td{padding: 10px;}tr{padding:20px; }</style>>";
            $tabla = $tabla . "<tr>";
            $tabla = $tabla . "	<td>Id Venta</td>";
            $tabla = $tabla . "	<td>Cliente</td>";
            $tabla = $tabla . "</tr>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $tabla = $tabla . "<tr>";
                $tabla = $tabla . "	<td>" . $row['idventa'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['nombre'] . "</td>";
                $tabla = $tabla . "</tr>";
            }
            $tabla = $tabla . "</table>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
        return $tabla;
    }

    function getTablaClientesPDF() {

        $sql = "(select  count(*) as Totalventas, cliente from admin.venta group by cliente)  order  by 1 desc";
        $tabla = "";
        try {
            $tabla = "<table <style> table{background: #F0F0F0 !important; margin-top:40px; width: auto;}
        td{padding: 10px;}tr{padding:20px; }</style>>";
            $tabla = $tabla . "<tr>";
            $tabla = $tabla . "	<td>No. de compras</td>";
            $tabla = $tabla . "	<td>Id Cliente</td>";
            $tabla = $tabla . "</tr>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $tabla = $tabla . "<tr>";
                $tabla = $tabla . "	<td>" . $row['totalventas'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['cliente'] . "</td>";
                $tabla = $tabla . "</tr>";
            }
            $tabla = $tabla . "</table>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
        return $tabla;
    }

    
}

?>
