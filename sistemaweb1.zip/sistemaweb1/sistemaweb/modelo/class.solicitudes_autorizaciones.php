<?php

ini_set('display_errors', 'off');
include_once("resources/class.database.php");

class solicitudes_autorizaciones {

    var $id_solicitud;
    var $id_paciente;
    var $medico;
    var $especialidad;
    var $fecha_hora;
    var $tipo_tratamiento;

    function solicitudes_autorizaciones() {
        
    }

    function select($id_solicitud) {
        $sql = "SELECT * FROM public.solicitudes_autorizaciones WHERE id_solicitud = $this->id_solicitud";
        try {
            $row = pg::query($sql);
            $row = pg_fetch_array($row);
            $this->id_solicitud = $row['id_solicitud'];
            $this->id_paciente = $row['id_paciente'];
            $this->medico = $row['medico'];
            $this->especialidad = $row['especialidad'];
            $this->fecha_hora = $row['fecha_hora'];
            $this->tipo_tratamiento = $row['tipo_tratamiento'];
            return true;
        } catch (DependencyException $e) {
            
        }
    }

    function delete($id_solicitud) {
        $sql = "DELETE FROM public.solicitudes_autorizaciones WHERE id_solicitud = $id_solicitud";
        try {
            pg::query("begin");
            $row = pg::query($sql);
            pg::query("commit");
            return "1";
        } catch (DependencyException $e) {
            pg::query("rollback");
            return "-1";
        }
    }

    function insert() {
        if ($this->validaP($this->id_solicitud) == false) {
            $sql = "INSERT INTO public.solicitudes_autorizaciones(id_solicitud, id_paciente, medico, especialidad,fecha_hora, tipo_tratamiento) VALUES (" . $this->id_solicitud . ", " . $this->id_paciente . ", '" . $this->medico . "', '" . $this->especialidad . "', '" . $this->fecha_hora . "', '" . $this->tipo_tratamiento . "')";
            try {
                pg::query("begin");
                $row = pg::query($sql);
                pg::query("commit");
                echo "1";
            } catch (DependencyException $e) {
                echo "Error: " . $e;
                pg::query("rollback");
                echo "-1";
            }
        } else {
            $sql = "UPDATE public.solicitudes_autorizaciones SET id_solicitud=" . $this->id_solicitud . ", id_paciente=" . $this->id_paciente . ", medico='" . $this->medico . "', especialidad='" . $this->especialidad . "', fecha_hora='" . $this->fecha_hora . "', tipo_tratamiento='" . $this->tipo_tratamiento . "' WHERE id_solicitud=" . $this->id_solicitud . "";
            pg::query("begin");
            $row = pg::query($sql);
            pg::query("commit");
            echo "2";
        }
    }

    function validaP($id_solicitud) {
        $sql = "SELECT * FROM public.solicitudes_autorizaciones WHERE id_solicitud = $id_solicitud";
        try {
            $row = pg::query($sql);
            if (pg_num_rows($row) == 0) {
                return false;
            } else {
                return true;
            }
        } catch (DependencyException $e) {
            //pg::query("rollback");
            return false;
        }
    }

    function getTabla() {

        $sql = "SELECT * FROM public.solicitudes_autorizaciones";
        try {
            echo "<div class='container' style='margin-top: 10px'>";
            echo "<table cellpadding='0' cellspacing='0' border='0' class='table table-striped table-bordered' id='example'>";
            echo "<thead>";
            echo "<tr>";
            echo "	<th>Id Resultado</th>";
            echo "	<th>Id Paciente</th>";
            echo "	<th>Médico</th>";
            echo "	<th>Especialidad</th>";
            echo "	<th>Fecha y hora y hora</th>";
            echo "	<th>Tipo de |tratamiento</th>";
            echo "	<th>.</th>";
            echo "</tr>";
            echo "</thead>";
            echo "<tbody>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<tr class='gradeA'>";
                echo "	<th>" . $row['id_solicitud'] . "</th>";
                echo "	<th>" . $row['id_paciente'] . "</th>";
                echo "	<th>" . $row['medico'] . "</th>";
                echo "	<th>" . $row['especialidad'] . "</th>";
                echo "	<th>" . $row['fecha_hora'] . "</th>";
                echo "	<th>" . $row['tipo_tratamiento'] . "</th>";
                echo "	<th><a href='#' class='btn btn-danger' onclick='elimina(\"" . $row['id_solicitud'] . "\")'><i class='icon-white icon-trash'></i></a>.<a href='#' class='btn btn-primary' onclick='edit(\"" . $row['id_solicitud'] . "\", \"" . $row['id_paciente'] . "\",\"" . $row['fecha_hora'] . "\", \"" . $row['medico'] . "\",\"" . $row['especialidad'] . "\", \"" . $row['tipo_tratamiento'] . "\")'><i class='icon-white icon-refresh'></i></a></th>";
                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
            echo "</div>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
    }

    function getLista() {

        $sql = "SELECT * FROM public.solicitudes_autorizaciones";
        try {
            echo "<SELECT name='id_solicitud'>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<OPTION value='" . $row['id_solicitud'] . "'> " . $row['descripcion'] . " </OPTION>";
            }
            echo "</SELECT>";
        } catch (DependencyException $e) {
            pg::query("rollback");
        }
    }

    function getAutocomplete() {
        $res = "";
        $sql = "SELECT * FROM public.solicitudes_autorizaciones";
        try {
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $res .= '"' . $row['id_solicitud'] . ', ' . $row['id_paciente'] . '"';
                $res .= ',';
            }
            $res = substr($res, 0, -2);
            $res = substr($res, 1);
        } catch (DependencyException $e) {
            
        }
        return $res;
    }

    function getTablaPDF() {

        $sql = "select * from public.solicitudes_autorizaciones";
        $tabla = "";
        try {
            $tabla = "<table <style> table{background: #F0F0F0 !important; margin-top:40px; width: auto;}
        td{padding: 10px;}tr{padding:20px; }</style>>";
            $tabla = $tabla . "<tr>";
            $tabla = $tabla . "	<td>Id Resultado</td>";
            $tabla = $tabla . "	<td>Id Paciente</td>";
            $tabla = $tabla . "	<td>Médico</td>";
            $tabla = $tabla . "	<td>Especialidad</td>";
                        $tabla = $tabla . "	<td>Fecha y hora</td>";
            $tabla = $tabla . "	<td>Tipo de tratamiento</td>";

            $tabla = $tabla . "</tr>";

            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $tabla = $tabla . "<tr>";
                $tabla = $tabla . "	<td>" . $row['id_solicitud'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['id_paciente'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['medico'] . "</td>";
                $tabla = $tabla . "	<td>$ " . $row['especialidad'] . "</td>";
                                $tabla = $tabla . "	<td>" . $row['fecha_hora'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['tipo_tratamiento'] . "</td>";
                $tabla = $tabla . "</tr>";
            }
            $tabla = $tabla . "</table>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
        return $tabla;
    }

    function getTablaInforme() {

        $sql = "(select especialidad, id, fecha_hora from public.solicitudes_autorizaciones) order by 1 desc";
        try {
            echo "<div class='container' style='margin-top: 10px'>";
            echo "<table>";
            echo "<thead>";
            echo "<tr>";
            echo "	<th>Especialidad</th>";
            echo "	<th>Id Solicitud</th>";
            echo "	<th>Tipo de tratamiento</th>";

            echo "</tr>";
            echo "</thead>";
            echo "<tbody>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<tr class='gradeA'>";
                echo "	<th>" . $row['especialidad'] . "</th>";
                echo "	<th>" . $row['id_solicitud'] . "</th>";
                echo "	<th>" . $row['fecha_hora'] . "</th>";

                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
            echo "</div>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
    }

    function getTablaInformePDF() {

        $sql = "(select especialidad, id, fecha_hora from public.solicitudes_autorizaciones) order by 1 desc";
        $tabla = "";
        try {
            $tabla = "<table <style> table{background: #F0F0F0 !important; margin-top:40px; width: auto;}
        td{padding: 10px;}tr{padding:20px; }</style>>";
            $tabla = $tabla . "<tr>";
            $tabla = $tabla . "	<td>Especialidad</td>";
            $tabla = $tabla . "	<td>Id Resultado</td>";
            $tabla = $tabla . "	<td>Fecha y hora</td>";
            $tabla = $tabla . "</tr>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $tabla = $tabla . "<tr>";
                $tabla = $tabla . "	<td>" . $row['especialidad'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['id_solicitud'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['fecha_hora'] . "</td>";

                $tabla = $tabla . "</tr>";
            }
            $tabla = $tabla . "</table>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
        return $tabla;
    }

}
