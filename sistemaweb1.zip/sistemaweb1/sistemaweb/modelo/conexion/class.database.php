<?php
ini_set('display_errors', 'on');

class PostgresException extends Exception {
    function __construct($msg) { parent::__construct($msg); }
}

class DependencyException extends PostgresException {
    function __construct() { parent::__construct("deadlock"); }
}
 

class pg{
    var $Conexion_ID = 0;
    var $Consulta_ID = 0;
    public static $connection;
    
    private static function connect() {
        self::$connection = @pg_connect("host=127.0.0.1 port=5432 dbname=SISTEMAWEB user=postgres password=ADMIN");
        if (self::$connection === FALSE) {
            throw(new PostgresException("Can't connect to database server."));
        }
    }
    
    public static function query($sql) {
        if (!isset(self::$connection)) {
            self::connect();
        }
        
        $result = pg_query(self::$connection, $sql); 
        if ($result === FALSE) {
            $error = pg_last_error(self::$connection);
            if (stripos($error, "deadlock detected") !== false) throw(new DependencyException());
            
            throw(new PostgresException($error.": ".$sql));
        }
         return $result;
    }
    
      function Ejecutar($sql) {
        if ($sql == "") {
            $this->Error = "no se ha especificado la consulta";
            return 0;
        }
        $this->Consulta_ID = pg_Exec($this->Conexion_ID, $sql);
        return $this->Consulta_ID;
    }
}
?>
