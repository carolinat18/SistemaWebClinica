<?php

ini_set('display_errors', 'on');
include_once("resources/class.database.php");

class paciente {

    var $id_paciente;
    var $nombre;
    var $apellido;
    var $fecha_nacimiento;
    var $direccion;
    var $telefono_contacto;
    var $correo_electronico;

    function paciente() {
        
    }

    function insert() {
        if ($this->validaP($this->id_paciente) == false) {
            $sql = "INSERT INTO public.paciente(id_paciente, nombre, apellido, fecha_nacimiento, direccion,telefono_contacto,correo_electronico)VALUES (" . $this->id_paciente . ", '" . $this->nombre . "', '" . $this->apellido . "', '" . $this->fecha_nacimiento . "', '" . $this->direccion . "', '" . $this->telefono_contacto . "', '" . $this->correo_electronico . "')";

            try {
                pg::query("begin");
                $row = pg::query($sql);

                pg::query("commit");
                return "1";
            } catch (DependencyException $e) {
                echo "Error: " . $e;
                pg::query("rollback");
                return "-1";
            }
        } else {
            $sql = "UPDATE public.paciente SET id_paciente=" . $this->id_paciente . ", nombre='" . $this->nombre . "', apellido='" . $this->apellido . "', fecha_nacimiento='" . $this->fecha_nacimiento . "', direccion='" . $this->direccion . "', telefono_contacto='" . $this->telefono_contacto . "', correo_electronico='" . $this->correo_electronico . "' WHERE id_paciente=" . $this->id_paciente . " ";

            pg::query("begin");
            $row = pg::query($sql);
            pg::query("commit");
            return "2";
        }
    }

    function validaP($id_paciente) {
        $sql = "SELECT * FROM public.paciente WHERE id_paciente=$id_paciente";
        try {
            $row = pg::query($sql);
            if (pg_num_rows($row) == 0) {
                return false;
            } else {
                return true;
            }
        } catch (DependencyException $e) {
            return false;
        }
    }

    function select($id_paciente) {
        $sql = "SELECT * FROM public.paciente WHERE id_paciente = $id_paciente";
        try {
            $row = pg::query($sql);
            if (pg_num_rows($row) == 0) {
                return "-1";
            }
            $row = pg_fetch_array($row);
            $this->id_paciente = $row['id_paciente'];
            $this->nombre = $row['nombre'];
            $this->apellido = $row['apellido'];
            $this->fecha_nacimiento = $row['fecha_nacimiento'];
            $this->direccion = $row['direccion'];
            $this->telefono_contacto = $row['telefono_contacto'];
            $this->correo_electronico = $row['correo_electronico'];
            $paciente = array($this->id_paciente, $this->nombre, $this->apellido, $this->fecha_nacimiento, $this->direccion, $this->telefono_contacto, $this->correo_electronico);
            $mensaje = implode(' - ', $paciente);
            return $mensaje;
        } catch (DependencyException $e) {
            
        }
    }

    function delete($id_paciente) {
        if ($this->validaP($id_paciente) == true) {
            $sql = "DELETE FROM public.paciente WHERE id_paciente = $id_paciente";
            try {
                pg::query("begin");
                $row = pg::query($sql);
                pg::query("commit");
                return "1";
            } catch (DependencyException $e) {
                pg::query("rollback");
                return "-1";
            }
        } else {
            return "-2";
        }
    }

// Ejemplo Funciones

 /*   function getTCombo() {

        $sql = "SELECT * FROM public.paciente";
        try {
            echo "<SELECT name=id_paciente>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<OPTION value='" . $row['id_paciente'] . "'> " . $row['apellido'] . " </OPTION>";
            }
            echo "</SELECT>";
        } catch (DependencyException $e) {
            pg::query("rollback");
        }
    }*/

    function getTabla() {

        $sql = "select * 
from public.paciente";
//where public.paciente.direccion = public.paciente.id_pacientedireccion";
        try {
            echo "<div class='container' style='margin-top: 10px'>";
            echo "<table cellpadding='0' cellspacing='0' border='0' class='table table-striped table-bordered' id_paciente='example'>";
            echo "<thead>";
            echo "<tr>";
            echo "	<th>Id</th>";
            echo "	<th>Nombre</th>";
            echo "	<th>Apellido</th>";
            echo "	<th>Fecha de Nacimiento</th>";
            echo "	<th>Dirección</th>";
            echo "	<th>Teléfono</th>";
            echo "	<th>Email</th>";

            echo "	<th>.</th>";
            echo "</tr>";
            echo "</thead>";
            echo "<tbody>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                echo "<tr class='gradeA'>";
                echo "	<th>" . $row['id_paciente'] . "</th>";
                echo "	<th>" . $row['nombre'] . "</th>";
                echo "	<th>" . $row['apellido'] . "</th>";
                echo "	<th>" . $row['fecha_nacimiento'] . "</th>";
                echo "	<th>" . $row['direccion'] . "</th>";
                echo "	<th>" . $row['telefono_contacto'] . "</th>";
                echo "	<th>" . $row['correo_electronico'] . "</th>";
                echo "	<th><a href='#' class='btn btn-danger' onclick='elimina(\"" . $row['id_paciente'] . "\")'><i class='icon-white icon-trash'></i></a>.<a href='#' class='btn btn-primary' onclick='edit(\"" . $row['id_paciente'] . "\", \"" . $row['nombre'] . "\", \"" . $row['apellido'] . "\", \"" . $row['fecha_nacimiento'] . "\", \"" . $row['telefono_contacto'] . "\", \"" . $row['direccion'] . "\")'><i class='icon-white icon-refresh'></i></a></th>";
                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
            echo "</div>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
    }

    function getLista() {
        $arrayResponse = null;
        try {
            $sql = "select * from public.paciente";
            $result = pg::query($sql);
            $arrayResponse = pg_fetch_array($result);
        } catch (Exception $ex) {
            $arrayResponse = null;
        }
        return $arrayResponse;
        ;
    }

    function getAutocomplete() {
        $res = "";
        $sql = "SELECT * FROM public.paciente";
        try {
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $res .= ' " ' . $row['id_paciente'] . ', ' . $row['nombre'] . ',' . $row['apellido'] . ',' . $row['fecha_nacimiento'] . ',' . $row['direccion'] . ',' . $row['telefono_contacto'] . ',' . $row['correo_electronico'] . ' " ';
                $res .= ',';
            }
            $res = substr($res, 0, -2);
            $res = substr($res, 1);
        } catch (DependencyException $e) {
            
        }
        return $res;
    }

    /*    function getComboBox() {

      $sql = "SELECT * FROM public.direccion";
      try {
      echo "<SELECT name='direccion' id_paciente='direccion'>";
      //pg::query("begin");
      $result = pg::query($sql);
      //pg::query("commit");
      while ($row = pg_fetch_array($result)) {
      echo "<OPTION value='" . $row['id_direccion'] . "'> " . $row['apellidoc'] . " </OPTION>";
      }
      echo "</SELECT>";
      } catch (DependencyException $e) {
      pg::query("rollback");
      }
      } */

    function getTablaPDF() {

        $sql = "select * from public.paciente";
        $tabla = "";
        try {
            $tabla = "<table <style> table{background: #F0F0F0 !important; margin-top:40px; wid_pacienteth: auto;}
        td{padding: 10px;}tr{padding:20px; }</style>>";
            $tabla = $tabla . "<tr>";
            $tabla = $tabla . "	<td>Id</td>";
            $tabla = $tabla . "	<td>Nombre</td>";
            $tabla = $tabla . "	<td>Apellido</td>";
            $tabla = $tabla . "	<td>Fecha de Nacimiento</td>";
            $tabla = $tabla . "	<td>Dirección</td>";
            $tabla = $tabla . "	<td>Teléfono</td>";
            $tabla = $tabla . "	<td>Email</td>";

            $tabla = $tabla . "</tr>";
            $result = pg::query($sql);
            while ($row = pg_fetch_array($result)) {
                $tabla = $tabla . "<tr>";
                $tabla = $tabla . "	<td>" . $row['id_paciente'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['nombre'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['apellido'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['fecha_nacimiento'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['direccion'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['telefono_contacto'] . "</td>";
                $tabla = $tabla . "	<td>" . $row['correo_electronico'] . "</td>";

                $tabla = $tabla . "</tr>";
            }
            $tabla = $tabla . "</table>";
        } catch (DependencyException $e) {
            echo "Procedimiento sql invalido en el servidor";
        }
        return $tabla;
    }

}

?>
