<!DOCTYPE html>
<html>
    <head>
    <html lang="en">

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <link href="icono.ico" type="image/x-icon" rel="shortcut icon" />
        <title>Login</title>

        <link rel="stylesheet" type="text/css" href="dist/css/dt/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="dist/css/dt/DT_bootstrap.css">
        <link rel="stylesheet" type="text/css" href="css/demo.css">
        <link rel="stylesheet" type="text/css" href="dist/css/../css/../../css/style.css">
        <script type="text/javascript" charset="utf-8" language="javascript" src="dist/js/dt/jquery.js"></script>
        <script type="text/javascript" charset="utf-8" language="javascript" src="dist/js/dt/jquery.dataTables.js"></script>
        <script type="text/javascript" charset="utf-8" language="javascript" src="dist/js/dt/DT_bootstrap.js"></script>
        <script src="dist/js/bootstrap.min.js"></script>
        <script src="dist/js/bootbox.js"></script>	 
        <script type="text/javascript">
            $(document).ready(function() {  // validar que la libreria ya descargo
                $("#boton").click(function() { // Se activa si le hacen click al botón
                    usuario = $("#usuario").val(); // Toma el valor de la caja de texto
                    password = $("#password").val(); // Toma el valor de la caja de texto
                    $.ajax({// Instrucción de AJAX de jQuery
                        type: "POST", // Método de envio
                        url: "controllers/validar.php", // Programa a llamar sin recargar
                        data: "usuario=" + usuario + "&password=" + password, // Los parámetros a enviar
                        success: function(html) { // Cunaod el programa se ejecuta (llama) y termina
                            // el resultado (lo que muestra el programa) se carga en 
                            // html
                            //alert(html); // Es muy necesario para saber que está retornado el
                            // programa llamado
                            if (html === "denegar") {
                                bootbox.alert("Usuario o contraseña incorrecta", function() {
                                });
                            }
                            else {
                                document.location = "vistas/inicio.php";
                            }
                            $("#mensaje").html("");
                        },
                        beforeSend: function() {
                            $("#mensaje").html("Validando ...");
                        }
                    });
                    return false;
                });
            });
        </script>
        <body>  
            <div id="contenedorlogin">
                <h1>Loguearse o <a href="CRUDs/registrarusuario_1.php">Registrarse</a></h1>
                <label for="usuario">Nombre de Usuario</label>
                <input type="text" name="usuario" placeholder="Username or email" required id="usuario">
                <label for="password">Password</label>
                <input type="password" name='password' placeholder="Password" required id="password" > 
                <button id="boton" type="submit" class="btn">Continuar</button><br>
            </div>

        </body>
    </html>
